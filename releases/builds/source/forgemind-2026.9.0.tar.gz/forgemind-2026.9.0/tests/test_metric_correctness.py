# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

"""回测指标的**数值正确性**验证(不是"能不能跑",是"算得对不对")

曾经的 bug:Sortino 的分母用了"仅负收益子集的标准差" downside.std(),
而不是标准的下行偏差 sqrt(mean(min(r,0)^2))。该实现会系统性高估分母,
使 Sortino 被低估约 15%(实测 1.0599 vs empyrical 1.2471)。

此前所有"跑通了"的测试都发现不了这个问题 —— 因为它不崩,只是算错。
本文件用 empyrical(已在依赖中)做第三方交叉校验。
"""

import numpy as np
import pandas as pd
import pytest

from forgemind.core.backtest.engine import SimpleBacktestEngine
from forgemind.core.strategies.base import MovingAverageCrossStrategy

empyrical = pytest.importorskip("empyrical")


def _fixture(n=500, seed=11):
    """确定性的价格序列,保证每次跑出同样的数字"""
    rng = np.random.default_rng(seed)
    close = 100 * np.exp(np.cumsum(rng.normal(0.0004, 0.018, n)))
    return pd.DataFrame({
        "open": close * (1 + rng.normal(0, 0.003, n)),
        "high": close * 1.01, "low": close * 0.99,
        "close": close, "volume": rng.integers(1_000_000, 5_000_000, n),
    })


def _run(df):
    strat = MovingAverageCrossStrategy(parameters={"fast_period": 10, "slow_period": 40})
    eng = SimpleBacktestEngine(initial_capital=100_000.0)
    res = eng.run(strat, df)
    equity = eng._simulate_equity(df, strat.generate_signals(df))
    return res, equity


class TestMetricsAgainstEmpyrical:
    """核心指标必须与第三方权威实现一致(浮点精度内)"""

    def test_sharpe_matches_empyrical(self):
        df = _fixture()
        res, equity = _run(df)
        r = equity.pct_change().dropna()
        assert res.sharpe == pytest.approx(float(empyrical.sharpe_ratio(r.values)), abs=1e-9)

    def test_max_drawdown_matches_empyrical(self):
        df = _fixture()
        res, equity = _run(df)
        r = equity.pct_change().dropna()
        assert res.max_drawdown == pytest.approx(
            float(empyrical.max_drawdown(r.values)), abs=1e-9
        )

    def test_sortino_matches_empyrical(self):
        """回归重点:Sortino 曾用错误的下行波动定义,与 empyrical 差 15%"""
        df = _fixture()
        res, equity = _run(df)
        r = equity.pct_change().dropna()
        assert res.sortino == pytest.approx(
            float(empyrical.sortino_ratio(r.values)), abs=1e-9
        )

    def test_sortino_uses_downside_deviation_definition(self):
        """显式验证:分母必须是全部周期的下行偏差,不是负收益子集标准差"""
        df = _fixture()
        res, equity = _run(df)
        r = equity.pct_change().dropna()
        downside_dev = float(np.sqrt(np.mean(np.minimum(r.to_numpy(), 0.0) ** 2)))
        expected = float(r.mean() / downside_dev * np.sqrt(252))
        assert res.sortino == pytest.approx(expected, abs=1e-9)

    def test_sortino_differs_from_the_wrong_formula(self):
        """防止有人"改回去":结果必须不等于旧的错误公式"""
        df = _fixture()
        res, equity = _run(df)
        r = equity.pct_change().dropna()
        wrong = r[r < 0].std()
        wrong_result = float(r.mean() / wrong * np.sqrt(252))
        assert abs(res.sortino - wrong_result) > 1e-6


class TestMetricsInternalConsistency:
    """自洽性:不需要第三方也能查出的矛盾"""

    def test_total_return_equals_equity_ratio(self):
        df = _fixture()
        res, equity = _run(df)
        assert res.total_return == pytest.approx(
            float(equity.iloc[-1] / equity.iloc[0] - 1), abs=1e-12
        )

    def test_equity_starts_at_initial_capital(self):
        df = _fixture()
        _, equity = _run(df)
        assert equity.iloc[0] == pytest.approx(100_000.0, abs=1e-6)

    def test_equity_never_negative(self):
        df = _fixture()
        _, equity = _run(df)
        assert (equity > 0).all()

    def test_max_drawdown_never_positive(self):
        df = _fixture()
        res, _ = _run(df)
        assert res.max_drawdown <= 0

    def test_trade_count_consistent(self):
        df = _fixture()
        strat = MovingAverageCrossStrategy(parameters={"fast_period": 10, "slow_period": 40})
        eng = SimpleBacktestEngine(initial_capital=100_000.0)
        res = eng.run(strat, df)
        sig = strat.generate_signals(df)
        equity = eng._simulate_equity(df, sig)
        trades = eng._extract_trades(df, sig, equity)
        assert len(trades) == res.n_trades

    def test_win_rate_consistent_with_trades(self):
        df = _fixture()
        strat = MovingAverageCrossStrategy(parameters={"fast_period": 10, "slow_period": 40})
        eng = SimpleBacktestEngine(initial_capital=100_000.0)
        res = eng.run(strat, df)
        sig = strat.generate_signals(df)
        equity = eng._simulate_equity(df, sig)
        trades = eng._extract_trades(df, sig, equity)
        if trades:
            wins = sum(1 for t in trades if t["win"])
            assert res.win_rate == pytest.approx(wins / len(trades), abs=1e-12)


class TestMetricsOnMultipleSeeds:
    """不能只在一个种子上碰巧通过"""

    @pytest.mark.parametrize("seed", [1, 7, 42, 99, 2024])
    def test_sharpe_sortino_dd_all_match(self, seed):
        df = _fixture(seed=seed)
        res, equity = _run(df)
        r = equity.pct_change().dropna()
        assert res.sharpe == pytest.approx(float(empyrical.sharpe_ratio(r.values)), abs=1e-8)
        assert res.sortino == pytest.approx(float(empyrical.sortino_ratio(r.values)), abs=1e-8)
        assert res.max_drawdown == pytest.approx(
            float(empyrical.max_drawdown(r.values)), abs=1e-8
        )


class TestICMetricsAreNotFabricated:
    """回归:ICIR / positive_ratio 必须来自真实 IC 序列

    曾经的 bug:
      * icir = ic_mean / 0.01(除以硬编码常数,只是把 IC 线性缩放)
      * ic_std = 0.01 写死
      * positive_ratio = 1.0 if ic>0 else 0.0(注释写"IC>0 的天数比例",实际只有 0/1)
    """

    @staticmethod
    def _panel(n_symbols=30, n_days=500, seed=5):
        import polars as pl

        rng = np.random.default_rng(seed)
        rows = []
        for i in range(n_symbols):
            c = 100 * np.exp(np.cumsum(rng.normal(0, 0.015, n_days)))
            d = pd.DataFrame({
                "date": pd.date_range("2024-01-01", periods=n_days),
                "symbol": f"S{i}", "close": c,
                "factor": rng.normal(0, 1, n_days),
            })
            d["fwd_ret_5"] = d.groupby("symbol")["close"].pct_change(5).shift(-5)
            rows.append(d)
        pdf = pd.concat(rows).dropna(subset=["fwd_ret_5", "factor"])
        return pl.from_pandas(pdf).lazy()

    def test_icir_comes_from_real_series(self):
        from forgemind.core.factors.ic_monitor import compute_ic

        r = compute_ic(self._panel(), "factor", forward_returns_col="fwd_ret_5")
        assert len(r.ic_series) > 50, "未产出逐期 IC 序列"
        expected = r.ic_series.mean() / r.ic_series.std(ddof=1)
        assert r.icir == pytest.approx(float(expected), abs=1e-9)

    def test_ic_std_is_series_std(self):
        from forgemind.core.factors.ic_monitor import compute_ic

        r = compute_ic(self._panel(), "factor", forward_returns_col="fwd_ret_5")
        assert r.ic_std == pytest.approx(float(r.ic_series.std(ddof=1)), abs=1e-12)

    def test_positive_ratio_is_a_real_fraction(self):
        from forgemind.core.factors.ic_monitor import compute_ic

        r = compute_ic(self._panel(), "factor", forward_returns_col="fwd_ret_5")
        assert r.positive_ratio == pytest.approx(float((r.ic_series > 0).mean()), abs=1e-12)

    def test_positive_ratio_not_a_binary_flag(self):
        from forgemind.core.factors.ic_monitor import compute_ic

        r = compute_ic(self._panel(), "factor", forward_returns_col="fwd_ret_5")
        assert r.positive_ratio not in (0.0, 1.0), "positive_ratio 退化成 0/1 标志位"

    def test_icir_not_the_old_fake_formula(self):
        from forgemind.core.factors.ic_monitor import compute_ic

        r = compute_ic(self._panel(), "factor", forward_returns_col="fwd_ret_5")
        assert not np.isclose(r.icir, r.ic_mean / 0.01)

    def test_ic_core_matches_scipy(self):
        """核心 IC 本身必须与 scipy 一致(之前就是对的,别改坏)"""
        from scipy import stats

        from forgemind.core.factors.ic_monitor import compute_ic

        lazy = self._panel()
        r = compute_ic(lazy, "factor", forward_returns_col="fwd_ret_5")
        pdf = lazy.collect().to_pandas().dropna(subset=["factor", "fwd_ret_5"])
        x, y = pdf["factor"].values, pdf["fwd_ret_5"].values
        assert r.ic_mean == pytest.approx(float(stats.pearsonr(x, y).statistic), abs=1e-9)
        assert r.rank_ic_mean == pytest.approx(float(stats.spearmanr(x, y).statistic), abs=1e-9)

    def test_batch_compute_ic_does_not_silently_drop_factors(self):
        """曾经的 bug:except: continue —— 出错的因子凭空消失且无任何提示"""
        from forgemind.core.factors.ic_monitor import batch_compute_ic

        lazy = self._panel()
        good = batch_compute_ic(lazy, ["factor"], forward_returns_col="fwd_ret_5")
        assert len(good) == 1
        mixed = batch_compute_ic(
            lazy, ["factor", "does_not_exist"], forward_returns_col="fwd_ret_5"
        )
        assert [m.factor for m in mixed] == ["factor"], "失败的因子应被记录而非静默消失"


def _independent_simulate(open_, close_, entries, exits, capital=100_000.0,
                          fee=0.0, slip=0.0):
    """参考实现:逐 bar 推演,只用当日 open/close

    与 SimpleBacktestEngine._simulate_equity 完全独立地写一遍,
    用来抓"资金曲线本身算错"这类错误 —— 只比对指标公式是不够的,
    因为指标公式和资金曲线可以一起错,两边对拍仍然一致。
    """
    n = len(open_)
    eq = np.empty(n)
    eq[0] = capital
    pos = 0
    for i in range(1, n):
        prev_close = close_[i - 1]
        if pos == 0 and entries[i - 1]:
            pos = 1
            entry = open_[i] * (1 + slip)
            eq[i] = eq[i - 1] * (1 - fee) * ((close_[i] / entry) if entry else 1.0)
        elif pos == 1 and exits[i - 1]:
            pos = 0
            step = (open_[i] * (1 - slip)) / prev_close - 1 if prev_close else 0.0
            eq[i] = eq[i - 1] * (1 + step) * (1 - fee)
        else:
            eq[i] = eq[i - 1] * ((close_[i] / prev_close) if pos == 1 else 1.0)
    return eq


class TestEquityCurveIsNotDoubleCounted:
    """核心回归:资金曲线不得重复计入持仓期涨幅

    曾经的 bug:卖出时用**整笔交易**的完整收益
        equity[i] = equity[i-1] * (1 + exit/entry - 1)
    而持仓期 [entry, i-1] 已逐日按 close 复利过,整段被算两遍。
    100 买 → 持有一日 105 → 110 卖:正确 110000,旧实现 115500。
    所有下游指标(总收益/Sharpe/Sortino/Calmar/胜率/盈亏比)因此全部虚高。
    """

    def test_single_two_day_trade(self):
        """最直白的复现:100 买,隔一天 105,110 卖 → 必须是 110000"""
        idx = pd.date_range("2024-01-01", periods=4)
        o = np.array([99.0, 100.0, 105.0, 110.0])
        c = o.copy()
        df = pd.DataFrame({"open": o, "high": c * 1.01, "low": c * 0.99,
                           "close": c, "volume": 1e6}, index=idx)
        sig = pd.DataFrame({"entries": [True, False, False, False],
                            "exits": [False, False, True, False]}, index=idx)
        eng = SimpleBacktestEngine(initial_capital=100_000.0, fees=0.0,
                                   slippage_bps=0.0, use_next_open=True)
        eq = eng._simulate_equity(df, sig)
        assert eq.iloc[3] == pytest.approx(110_000.0, abs=1e-6)

    @pytest.mark.parametrize("seed", list(range(10)))
    def test_matches_independent_simulation(self, seed):
        """随机场景逐点对拍,任何一根 bar 都不允许有偏差"""
        rng = np.random.default_rng(seed)
        n = 300
        o = np.abs(100 + np.cumsum(rng.normal(0, 1, n)))
        c = np.abs(100 + np.cumsum(rng.normal(0, 1, n)))
        ent = np.zeros(n, dtype=bool)
        ex = np.zeros(n, dtype=bool)
        for i in range(20, n - 10, 17):
            ent[i] = True
            if i + 9 < n:
                ex[i + 9] = True
        df = pd.DataFrame({"open": o, "high": c * 1.01, "low": c * 0.99,
                           "close": c, "volume": 1e6},
                          index=pd.date_range("2024-01-01", periods=n))
        sig = pd.DataFrame({"entries": ent, "exits": ex}, index=df.index)
        eng = SimpleBacktestEngine(initial_capital=100_000.0, fees=0.0,
                                   slippage_bps=0.0, use_next_open=True)
        got = eng._simulate_equity(df, sig).to_numpy()
        want = _independent_simulate(o, c, ent, ex)
        assert np.max(np.abs(got - want)) < 1e-6, "资金曲线与独立模拟不一致"

    def test_with_fees_and_slippage(self):
        """带手续费和滑点时同样要对得上"""
        rng = np.random.default_rng(3)
        n = 250
        o = np.abs(100 + np.cumsum(rng.normal(0, 1, n)))
        c = np.abs(100 + np.cumsum(rng.normal(0, 1, n)))
        ent = np.zeros(n, dtype=bool)
        ex = np.zeros(n, dtype=bool)
        for i in range(15, n - 8, 13):
            ent[i] = True
            if i + 7 < n:
                ex[i + 7] = True
        df = pd.DataFrame({"open": o, "high": c * 1.01, "low": c * 0.99,
                           "close": c, "volume": 1e6},
                          index=pd.date_range("2024-01-01", periods=n))
        sig = pd.DataFrame({"entries": ent, "exits": ex}, index=df.index)
        eng = SimpleBacktestEngine(initial_capital=100_000.0, fees=0.0005,
                                   slippage_bps=8.0, use_next_open=True)
        got = eng._simulate_equity(df, sig).to_numpy()
        want = _independent_simulate(o, c, ent, ex, fee=0.0005, slip=8.0 / 10000)
        assert np.max(np.abs(got - want)) < 1e-6

    def test_return_cannot_exceed_the_actual_price_move(self):
        """总收益不得超过标的实际的涨跌幅"""
        idx = pd.date_range("2024-01-01", periods=4)
        o = np.array([99.0, 100.0, 105.0, 110.0])
        c = o.copy()
        df = pd.DataFrame({"open": o, "high": c * 1.01, "low": c * 0.99,
                           "close": c, "volume": 1e6}, index=idx)
        # 这里走完整 run() 流程,信号由策略自己产生,无需手工构造
        strat = MovingAverageCrossStrategy(parameters={"fast_period": 1, "slow_period": 2})
        eng = SimpleBacktestEngine(initial_capital=100_000.0, fees=0.0,
                                   slippage_bps=0.0, use_next_open=True)
        res = eng.run(strat, df)
        assert res.total_return <= 0.10 + 1e-9, "收益被虚高到超过真实涨幅"


class TestEntryBarIntradayMoveIsNotLost:
    """买入当日 open→close 的涨幅不得丢弃

    曾经的 bug:买入 bar 只扣手续费,当日日内涨幅整段丢失,而卖出 bar 却补了
    close[i-1]→卖出价 —— 进出两端不对称。100 买 / 130 卖(同日)时引擎报 0%,
    正确是 +30%。
    """

    def test_same_day_gap_up_is_counted(self):
        idx = pd.date_range("2024-01-01", periods=4)
        o = np.array([99.0, 100.0, 130.0, 130.0])
        c = np.array([99.0, 130.0, 130.0, 130.0])
        df = pd.DataFrame({"open": o, "high": c * 1.01, "low": c * 0.99,
                           "close": c, "volume": 1e6}, index=idx)
        sig = pd.DataFrame({"entries": [True, False, False, False],
                            "exits": [False, True, False, False]}, index=idx)
        eng = SimpleBacktestEngine(initial_capital=100_000.0, fees=0.0,
                                   slippage_bps=0.0, use_next_open=True)
        eq = eng._simulate_equity(df, sig)
        assert eq.iloc[2] == pytest.approx(130_000.0, abs=1e-6)

    def test_entry_and_exit_are_symmetric(self):
        """进出两端必须对称:同样的日内波动不能只算一边"""
        idx = pd.date_range("2024-01-01", periods=4)
        o = np.array([99.0, 100.0, 130.0, 130.0])
        c = np.array([99.0, 130.0, 130.0, 130.0])
        df = pd.DataFrame({"open": o, "high": c * 1.01, "low": c * 0.99,
                           "close": c, "volume": 1e6}, index=idx)
        sig = pd.DataFrame({"entries": [True, False, False, False],
                            "exits": [False, True, False, False]}, index=idx)
        eng = SimpleBacktestEngine(initial_capital=100_000.0, fees=0.0,
                                   slippage_bps=0.0, use_next_open=True)
        eq = eng._simulate_equity(df, sig)
        want = _independent_simulate(o, c, sig["entries"].values, sig["exits"].values)
        assert np.allclose(eq.to_numpy(), want, atol=1e-6)

    def test_repeated_random_scenarios(self):
        """随机场景下与独立实现逐点一致(含日内跳空)"""
        for seed in range(10):
            rng = np.random.default_rng(seed + 100)
            n = 250
            o = np.abs(100 + np.cumsum(rng.normal(0, 2.0, n)))
            c = np.abs(100 + np.cumsum(rng.normal(0, 2.0, n)))
            ent = np.zeros(n, dtype=bool)
            ex = np.zeros(n, dtype=bool)
            for i in range(10, n - 5, 11):
                ent[i] = True
                if i + 3 < n:
                    ex[i + 3] = True
            df = pd.DataFrame({"open": o, "high": c * 1.01, "low": c * 0.99,
                               "close": c, "volume": 1e6},
                              index=pd.date_range("2024-01-01", periods=n))
            sig = pd.DataFrame({"entries": ent, "exits": ex}, index=df.index)
            eng = SimpleBacktestEngine(initial_capital=100_000.0, fees=0.0,
                                       slippage_bps=0.0, use_next_open=True)
            got = eng._simulate_equity(df, sig).to_numpy()
            want = _independent_simulate(o, c, ent, ex)
            assert np.max(np.abs(got - want)) < 1e-6, f"seed {seed} 资金曲线不一致"
