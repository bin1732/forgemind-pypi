# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

import argparse  # noqa: E402
import asyncio  # noqa: E402
import io  # noqa: E402
import os  # noqa: E402
import sys  # noqa: E402

from forgemind.core.config.settings import get_settings  # noqa: E402
from forgemind.core.observability.logging import get_logger, setup_logging  # noqa: E402

logger = get_logger("forgemind.cli")


def _force_utf8_stdio() -> None:
    """Windows 控制台默认是 GBK/cp1252,打印中文与 emoji 会直接崩

    真实故障:Windows 上跑 `forgemind signal` 抛
    UnicodeEncodeError: 'charmap' codec can't encode characters
    —— 一个中文 Windows 用户装完就用不了。

    这里不依赖 `reconfigure`:部分环境(含 PyInstaller 冻结包)拿不到它,
    因此直接用 TextIOWrapper 包一层 buffer 替换 sys.stdout / sys.stderr。
    """
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name, None)
        if stream is None:
            continue
        buffer = getattr(stream, "buffer", None)
        if buffer is None:  # 已被替换过
            continue
        encoding = (getattr(stream, "encoding", "") or "").lower().replace("-", "")
        if encoding in ("utf8", "utf_8"):
            continue
        try:
            wrapped = io.TextIOWrapper(
                buffer, encoding="utf-8", errors="replace", line_buffering=True
            )
            setattr(sys, name, wrapped)
        except (ValueError, OSError):  # pragma: no cover
            pass


_force_utf8_stdio()


def cmd_backtest(args):
    """跑一个示例回测"""
    import numpy as np
    import pandas as pd

    from forgemind.core.backtest.engine import SimpleBacktestEngine
    from forgemind.core.strategies.base import MovingAverageCrossStrategy  # noqa: F401

    if getattr(args, "list_strategies", False):
        from forgemind.core.strategies.library import available_strategies
        print("=== 可用策略 ===")
        for name, kind in available_strategies().items():
            print(f"  {name:26} {kind}")
        return

    print(f"Running backtest: {args.strategy} fast={args.fast} slow={args.slow}")

    # Demo 数据
    dates = pd.date_range(args.start, args.end, freq="D")
    n = len(dates)
    np.random.seed(42)
    close = 100 * np.exp(np.cumsum(np.random.normal(0.0005, 0.02, n)))
    price_df = pd.DataFrame({
        "open": close * (1 + np.random.normal(0, 0.005, n)),
        "high": close * (1 + np.abs(np.random.normal(0, 0.01, n))),
        "low": close * (1 - np.abs(np.random.normal(0, 0.01, n))),
        "close": close,
        "volume": np.random.randint(1_000_000, 10_000_000, n),
        "symbol": "DEMO",
    }, index=dates)
    price_df.index.name = "date"

    from forgemind.core.strategies.extended_library import list_strategies

    extended = list_strategies()
    if args.strategy in extended:
        # 批量策略:经 adapter 适配成引擎接口
        from forgemind.core.strategies.library import (
            _EXTENDED_STRATEGY_PARAMS,
            get_extended_strategy,
        )
        hint = _EXTENDED_STRATEGY_PARAMS.get(args.strategy)
        if hint:
            print(f"⚠️  {args.strategy} 需要额外参数,无法直接回测: {hint}")
            sys.exit(1)
        strategy = get_extended_strategy(args.strategy)
    else:
        from forgemind.core.strategies.library import get_strategy_class
        strategy_class = get_strategy_class(args.strategy)
        strategy = strategy_class(parameters={
            "fast_period": args.fast,
            "slow_period": args.slow,
        })

    engine = SimpleBacktestEngine(initial_capital=args.capital)
    result = engine.run(strategy, price_df)
    print("\n=== Result ===")
    print(f"  Total Return: {result.total_return:.2%}")
    print(f"  Sharpe: {result.sharpe:.2f}")
    print(f"  Max Drawdown: {result.max_drawdown:.2%}")
    print(f"  Trades: {result.n_trades}")

def cmd_agent(args):
    """跑一个 AI 决策"""
    from datetime import datetime

    from forgemind.core.agents.portfolio_context import (
        PortfolioContext,
        PortfolioPosition,
        run_decision,
    )

    print(f"Running AI decision: {args.symbol}")

    portfolio = PortfolioContext(
        cash=args.cash,
        total_equity=args.equity,
        positions=[
            PortfolioPosition(
                symbol=args.symbol,
                quantity=args.position_qty,
                avg_price=args.position_price,
            )
        ] if args.position_qty > 0 else [],
    )

    state = asyncio.run(run_decision(
        symbol=args.symbol,
        as_of=datetime.now(),
        portfolio=portfolio,
        thread_id=f"cli-{args.symbol}",
    ))

    pm = state.get("pm_decision")
    if pm:
        print("\n=== Decision ===")
        print(f"  Direction: {pm.get('direction')}")
        print(f"  Quantity: {pm.get('quantity')}")
        print(f"  Final Weight: {pm.get('final_weight'):.2%}")
        print(f"  Current Weight: {pm.get('current_weight'):.2%}")
        print(f"  Confidence: {pm.get('confidence'):.2%}")
        print(f"  Rationale: {pm.get('rationale')}")
    else:
        print("\n=== Pending Human Review ===")
        print(f"  requires_human_review: {state.get('requires_human_review')}")
        print(f"  bull: {state.get('bull_case', {}).get('thesis')}")
        print(f"  bear: {state.get('bear_case', {}).get('thesis')}")

    # 落盘组合快照,让 MCP query_portfolio / 后续决策能读到真实持仓
    try:
        from forgemind.core.data.storage import save_portfolio_snapshot

        snap = save_portfolio_snapshot(portfolio)
        print(f"\n  Portfolio snapshot saved: {snap}")
    except Exception as e:  # 落盘失败不该让整个决策失败
        print(f"\n  ⚠️  组合快照落盘失败({type(e).__name__}),MCP query_portfolio 将读到空组合")


def cmd_mcp(args):
    """启动 MCP server"""
    from forgemind.mcp.server import main as mcp_main
    mcp_main()

def cmd_pick(args):
    """选股 Agent — 选 top N"""
    from forgemind.core.agents.stock_picker import StockPickerAgent

    symbols = args.symbols.split(",") if args.symbols else None
    if not symbols:
        symbols = ["600519", "000001", "601318", "600036", "000333",
                   "601398", "601988", "600028", "601857", "600585"]

    print(f"Selecting top {args.top_n} from {len(symbols)} symbols...")
    picker = StockPickerAgent()
    picks = asyncio.run(picker.pick(universe=symbols, top_n=args.top_n))

    # 没有结果时必须说清原因,而不是只留一句 "Top 0 picks"
    short = dict(getattr(picker, "last_insufficient", {}) or {})
    if not picks and short:
        print("\n=== Top 0 picks ===\n")
        print(f"  {len(short)} 个标的因 K 线数据不足被跳过 "
              f"(至少需要 {StockPickerAgent.MIN_BARS} 根):")
        for sym, n in list(short.items())[:6]:
            got = f"仅 {n} 根" if n else "库里没有该标的"
            print(f"    {sym:12} {got}")
        print("\n  先拉更长的历史区间再试,例如:")
        print(f"    forgemind etl --symbols {','.join(list(short)[:3])} "
              f"--start 2022-01-01 --end 2024-12-31")
        return
    if not picks:
        print("\n=== Top 0 picks ===\n")
        print("  候选标的都没有 K 线数据。先跑 `forgemind etl` 拉取数据。")
        return

    print(f"\n=== Top {len(picks)} picks ===\n")
    for i, p in enumerate(picks, 1):
        print(f"#{i} {p.symbol} | {p.direction.upper()} | score={p.score:.3f} | conf={p.confidence:.2%}")
        print(f"   {p.rationale}\n")
    if short:
        print(f"  (另有 {len(short)} 个标的因数据不足被跳过)")

def cmd_etl(args):
    """AKShare 数据 ETL"""
    from forgemind.core.data.akshare_etl import AKShareETL

    symbols = args.symbols.split(",") if args.symbols else ["600519", "000001"]
    print(f"Running AKShare ETL for {len(symbols)} symbols ({args.start} → {args.end})...")

    etl = AKShareETL()
    stats = asyncio.run(etl.run(symbols=symbols, start=args.start, end=args.end))
    n_klines = (stats or {}).get("klines", 0)
    failures = (stats or {}).get("failures") or {}
    ok_syms = (stats or {}).get("ok_symbols", 0)
    if n_klines:
        print(f"✅ ETL complete — {n_klines} bars from {ok_syms} symbols")
        print("   Next: forgemind pick --symbol 600519.SH")
        if failures:
            total_fail = sum(failures.values())
            print(f"   ⚠️  {total_fail} 个标的取数失败:")
            for reason, cnt in failures.items():
                print(f"        {cnt}× {reason}")
    else:
        print("⚠️  ETL 拉到 0 条数据,没有写入任何 K 线。")
        if failures:
            print("   失败原因分类:")
            for reason, cnt in failures.items():
                print(f"        {cnt}× {reason}")
        else:
            try:
                import akshare  # noqa: F401

                print("   akshare 已安装但未取到数据,请检查网络或日期区间。")
            except ImportError:
                print("   akshare 未安装 → pip install 'forgemind[cn]'")
        print("   代码格式应为 6 位(如 600519),而非 600519.SH")
        sys.exit(1)

def cmd_broker_test(args):
    """Stub: ForgeMind is research-layer, no broker dependency.
    For execution, use vnpy / nautilus_trader / your broker's SDK.
    """
    print("ℹ️  ForgeMind is a research-layer Agent framework.")
    print("    No broker SDK is bundled. We output signals via:")
    print("      • MCP output_signal tool")
    print("      • CLI forgemind signal")
    print("      • Natural-language decision log (Markdown)")
    print()
    print("    For execution, plug the signal into:")
    print("      • vnpy (CTP / MiniQMT)")
    print("      • nautilus_trader (multi-broker)")
    print("      • your broker's SDK (ccxt / ib_insync / etc)")

def cmd_router_demo(args):
    """Model Router demo"""
    from forgemind.core.ai.router import quick_route_demo
    quick_route_demo()

def cmd_info(args):
    """显示配置"""
    settings = get_settings()
    print("=== ForgeMind Config ===")
    print(f"  Env: {settings.env}")
    print(f"  Mode: {settings.mode}")
    print(f"  Version: {settings.version}")
    print(f"  API: {settings.api_host}:{settings.api_port}")
    print(f"  PG: {settings.pg_host}:{settings.pg_port}")
    print(f"  ClickHouse: {settings.ch_host}:{settings.ch_port}")
    print(f"  Data dir: {settings.data_dir}")

def main():
    parser = argparse.ArgumentParser(prog="forgemind", description="ForgeMind CLI")
    subparsers = parser.add_subparsers(dest="command")

    # info
    subparsers.add_parser("info", help="Show config")

    # backtest
    parser_bt = subparsers.add_parser("backtest", help="Run backtest")
    parser_bt.add_argument(
        "--strategy",
        default="ma_cross",
        help=(
            "策略名。可选:ma_cross / mean_reversion / momentum / bollinger / buy_hold "
            "(on_bar 策略),以及 TimeSeriesMomentum / CrossSectionalMomentum / "
            "MomentumRotation / OrnsteinUhlenbeck / RSIReversion / MaxSharpe / "
            "RiskParity 等扩展策略。`forgemind backtest --list-strategies` 看全部。"
        ),
    )
    parser_bt.add_argument(
        "--list-strategies",
        action="store_true",
        help="列出全部可用策略后退出",
    )
    parser_bt.add_argument("--fast", type=int, default=5)
    parser_bt.add_argument("--slow", type=int, default=20)
    parser_bt.add_argument("--start", default="2024-01-01")
    parser_bt.add_argument("--end", default="2024-12-31")
    parser_bt.add_argument("--capital", type=float, default=100_000)
    parser_bt.set_defaults(func=cmd_backtest)

    # agent
    parser_agent = subparsers.add_parser("agent", help="Run AI decision")
    parser_agent.add_argument("--symbol", default="600519.SH")
    parser_agent.add_argument("--cash", type=float, default=80_000)
    parser_agent.add_argument("--equity", type=float, default=200_000)
    parser_agent.add_argument("--position-qty", type=int, default=100)
    parser_agent.add_argument("--position-price", type=float, default=1500)
    parser_agent.set_defaults(func=cmd_agent)

    # mcp
    parser_mcp = subparsers.add_parser("mcp", help="Start MCP server")
    parser_mcp.set_defaults(func=cmd_mcp)

    # router-demo
    parser_router = subparsers.add_parser("router-demo", help="Demo model router")
    parser_router.set_defaults(func=cmd_router_demo)

    # pick
    parser_pick = subparsers.add_parser("pick", help="Stock picker agent — 选股")
    parser_pick.add_argument("--symbols", help="Comma-separated symbols")
    parser_pick.add_argument("--top-n", type=int, default=5)
    parser_pick.set_defaults(func=cmd_pick)

    # etl
    parser_etl = subparsers.add_parser("etl", help="AKShare 数据 ETL(免费拉 A 股)")
    parser_etl.add_argument("--symbols", help="Comma-separated")
    parser_etl.add_argument("--start", default="2024-01-01")
    parser_etl.add_argument("--end", default="2024-12-31")
    parser_etl.set_defaults(func=cmd_etl)

    # broker-test
    parser_signal = subparsers.add_parser("signal", help="Show research-layer signal output interface(no broker bundled)")
    parser_signal.set_defaults(func=cmd_broker_test)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # CLI 默认把内部事件日志压到 WARNING:否则 `forgemind agent` 的输出里
    # 会混进十几行事件日志,真正的决策结果被淹没。
    # 需要排查时用 FORGEMIND_LOG_LEVEL=info 打开(大小写均可)。
    if not os.environ.get("FORGEMIND_LOG_LEVEL"):
        os.environ["FORGEMIND_LOG_LEVEL"] = "WARNING"
    setup_logging()

    if args.command == "info":
        cmd_info(args)
    else:
        args.func(args)

if __name__ == "__main__":
    main()
