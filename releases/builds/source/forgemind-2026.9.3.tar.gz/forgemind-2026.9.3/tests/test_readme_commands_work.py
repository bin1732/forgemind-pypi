# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

"""README 里的命令必须真的能跑

曾经的 bug:README 写
    pip install --extra-index-url .../pypi/simple/forgemind/ forgemind
pip 会把项目名再拼一次,实际请求 .../simple/forgemind/forgemind/ → 404,
用户照抄得到 "No matching distribution found"。

当时只用 curl 验过 URL 可达就以为没问题,**从没真跑过 pip** ——
这类"看起来对"的文档缺陷只能靠真执行发现。
"""

import re
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
README = ROOT / "README.md"


def _readme_commands(prefix="pip install"):
    text = README.read_text(encoding="utf-8")
    return [x.strip() for x in text.splitlines() if x.strip().startswith(prefix)]


class TestReadmeInstallCommand:
    def test_readme_has_install_command(self):
        assert _readme_commands(), "README 里没有 pip install 命令"

    def test_index_url_has_no_trailing_project_name(self):
        """--index-url / --extra-index-url 不能以 /<项目名> 结尾

        pip 会自己拼上项目名,带了就会变成 .../forgemind/forgemind/。
        """
        for cmd in _readme_commands():
            for flag in ("--index-url", "--extra-index-url"):
                for m in re.finditer(rf"{flag}\s+(\S+)", cmd):
                    url = m.group(1)
                    assert not url.rstrip("/").endswith("/forgemind"), (
                        f"{flag} 带了项目名,pip 会再拼一次导致 404: {url}\n"
                        f"  命令: {cmd}"
                    )

    @pytest.mark.slow
    def test_install_command_actually_resolves(self, tmp_path):
        """真跑一次 pip(只解析不安装),确认用户能装上"""
        cmd = _readme_commands()[0]
        dl = cmd.replace("pip install",
                         f"{sys.executable} -m pip download --no-deps -d {tmp_path}")
        r = subprocess.run(dl, shell=True, capture_output=True, text=True, timeout=420)
        assert r.returncode == 0, (
            f"README 的安装命令执行失败:\n  {cmd}\n"
            f"{(r.stdout or '')[-400:]}\n{(r.stderr or '')[-400:]}"
        )
        assert list(tmp_path.glob("*.whl")), "命令成功但没拿到 wheel"


class TestReadmeClaimsMatchCode:
    def test_no_dead_links_to_missing_files(self):
        text = README.read_text(encoding="utf-8")
        for m in re.finditer(r"\]\((?!https?://)([^)#]+)\)", text):
            target = m.group(1).strip()
            if not (ROOT / target).exists():
                pytest.fail(f"README 存在死链: ({target})")

    def test_no_docker_claim_without_dockerfile(self):
        text = README.read_text(encoding="utf-8")
        if "docker run" in text:
            assert (ROOT / "Dockerfile").exists(), (
                "README 提到 docker run,但仓库里没有 Dockerfile")

    def test_test_file_count_is_accurate(self):
        text = README.read_text(encoding="utf-8")
        m = re.search(r"(\d+)\s+test files", text)
        if m:
            actual = len(list((ROOT / "tests").glob("test_*.py")))
            assert actual == int(m.group(1)), (
                f"README 称 {m.group(1)} 个测试文件,实际 {actual}")
