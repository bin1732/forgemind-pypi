# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

"""OTLP 导出的时间单位必须是纳秒

曾经的 bug:TraceExporter.to_otlp 把 startTime 写成
`int(start_time * 1_000_000)`(微秒)、duration 写成 `int(duration_ms * 1_000)`。
OTLP / OpenTelemetry 规范要求两者都是**纳秒**,于是导出的 trace 比真实时间
小 1000 倍 —— 导入 Jaeger / Tempo / Datadog 后时间轴完全错位,
而此前没有任何测试断言过单位,所以一直没被发现。
"""

import json

from forgemind.core.observability.trace_exporter import TraceExporter
from forgemind.core.observability.tracing import get_tracer
from forgemind.core.observability.tracing import span as _span

NS_PER_SEC = 1_000_000_000
NS_PER_MS = 1_000_000


class TestOtlpTimeUnits:
    def _one_span(self, tmp_path):
        tracer = get_tracer()
        tracer.clear()
        with _span("unit-probe"):
            pass
        exp = TraceExporter(tracer)
        path = tmp_path / "otlp.json"
        exp.to_otlp(str(path))
        return json.loads(path.read_text())["resourceSpans"][0]["scopeSpans"][0]["spans"][0]

    def test_start_time_is_nanoseconds(self, tmp_path):
        import time

        before = time.time()
        span = self._one_span(tmp_path)
        after = time.time()
        # startTime 应落在 [before, after] 的纳秒区间内
        assert before * NS_PER_SEC <= span["startTime"] <= after * NS_PER_SEC, (
            f"startTime={span['startTime']} 不在纳秒区间 "
            f"[{before * NS_PER_SEC:.0f}, {after * NS_PER_SEC:.0f}]"
        )

    def test_duration_is_nanoseconds(self, tmp_path):
        """一个 sleep 20ms 的 span,duration 应约 2×10^7 纳秒,而不是 2×10^4 微秒数"""
        import time

        tracer = get_tracer()
        tracer.clear()
        with _span("dur-probe"):
            time.sleep(0.02)
        exp = TraceExporter(tracer)
        path = tmp_path / "d.json"
        exp.to_otlp(str(path))
        span = json.loads(path.read_text())["resourceSpans"][0]["scopeSpans"][0]["spans"][0]
        d = span["duration"]
        # 20ms → 约 2.0e7 ns
        assert 1.0e7 < d < 5.0e7, f"duration={d} 不像纳秒(20ms 应约 2e7)"
        # 若误用微秒则约 2e4;若误用毫秒则约 20
        assert d > 1.0e5, f"duration={d} 像是微秒/毫秒而非纳秒"

    def test_span_carries_otlp_shape(self, tmp_path):
        span = self._one_span(tmp_path)
        for k in ("traceId", "spanId", "operationName", "startTime", "duration", "tags", "logs"):
            assert k in span, f"缺少 OTLP 字段 {k}"
