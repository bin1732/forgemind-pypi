# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

from typing import TYPE_CHECKING, Optional

from pydantic import BaseModel, Field  # noqa: E402

if TYPE_CHECKING:
    import pandas as pd

from forgemind.core.data.storage import DuckDBStorage  # noqa: E402
from forgemind.core.observability.logging import get_logger  # noqa: E402

logger = get_logger("forgemind.stock_picker")

# 因子权重(所有因子均已归一化到 [0,1],统一"越大越好")
WEIGHTS = {
    "momentum": 0.30,
    "trend": 0.30,
    "volume_price": 0.20,
    "volatility": 0.10,
    "mean_reversion": 0.10,
}

class StockPick(BaseModel):
    """选股结果"""
    symbol: str
    score: float  # 综合评分 0-1
    direction: str  # "buy" / "hold" / "sell"
    confidence: float  # 0-1
    rationale: str  # 自然语言解释
    factors: dict[str, float] = Field(default_factory=dict)  # 各因子得分

class StockPickerAgent:
    """
    选股 Agent — 不需要 LLM,纯规则 + 多策略投票

    多策略:
    1. 动量策略(过去 20/60 日收益)
    2. 均值回归(偏离均线)
    3. 趋势跟踪(MA 交叉)
    4. 量价配合(放量上涨)

    综合评分 → Top N
    """

    def __init__(self, db: DuckDBStorage | None = None):
        self.db = db or DuckDBStorage()
        self.lookbacks = [5, 20, 60]  # 多窗口
        logger.info("stock_picker_init")

    async def pick(
        self,
        universe: list[str],
        top_n: int = 10,
        as_of: str | None = None,
    ) -> list[StockPick]:
        """
        从 universe 选 top N 个

        Args:
            universe: 候选股票代码列表("600519" 格式,不带交易所后缀)
            top_n: 返回 top N
            as_of: 截至日期(None = 最新)

        Returns:
            StockPick 列表,按 score 降序
        """
        picks = []
        raw: list[tuple[str, pd.DataFrame, dict[str, float]]] = []

        for symbol in universe:
            df = self._get_kline(symbol, as_of)
            if df is None or len(df) < 60:
                continue
            raw.append((symbol, df, self._compute_raw_factors(df)))

        # 横截面排名归一化
        #
        # 曾经的 bug:因子用固定 scale=0.05 做线性归一化,任何超过 ±5% 的动量
        # 都被压到 0 或 1 —— 30% 权重的动量因子对绝大多数标的退化成 0/1 标志,
        # 完全丧失区分度(实测 -15% 与 -5% 同为 0.0,+8%/+15%/+30% 同为 1.0)。
        # 改为在**当期横截面内**取百分位排名,任何分布下都保持区分度。
        norm = self._cross_sectional_normalize([r[2] for r in raw])

        for (symbol, _df, factors), nf in zip(raw, norm):
            score = sum(nf[k] * WEIGHTS[k] for k in factors)
            pick = self._build_pick(symbol, score, nf)
            if pick:
                picks.append(pick)

        picks.sort(key=lambda p: p.score, reverse=True)
        top = picks[:top_n]

        logger.info(
            "stock_picker_complete",
            universe_size=len(universe),
            top_n=len(top),
            top_score=top[0].score if top else 0,
        )
        return top

    async def _evaluate_symbol(self, symbol: str, as_of: str | None) -> StockPick | None:
        """评估一个 symbol(兼容入口:单标的时横截面退化为常量 0.5)"""
        df = self._get_kline(symbol, as_of)
        if df is None or len(df) < 60:
            return None
        raw = self._compute_raw_factors(df)
        # 单标的没有横截面可比,统一给中性 0.5
        return self._build_pick(symbol, 0.5, dict.fromkeys(raw, 0.5))

    def _compute_raw_factors(self, df) -> dict[str, float]:
        """计算**未归一化**的原始因子值

        归一化交给 _cross_sectional_normalize 在整个 universe 上做,
        这里只负责把真实数据变成可比较的数值。
        """
        close = df["close"]
        volume = df["volume"]

        # === 因子 1:动量(20/60 日混合)===
        mom_20 = float(close.iloc[-1] / close.iloc[-20] - 1) if len(close) >= 20 else 0.0
        mom_60 = float(close.iloc[-1] / close.iloc[-60] - 1) if len(close) >= 60 else 0.0
        momentum = mom_20 * 0.6 + mom_60 * 0.4

        # === 因子 2:趋势(MA 排列,取连续值而非三档)===
        ma5 = float(close.rolling(5).mean().iloc[-1])
        ma20 = float(close.rolling(20).mean().iloc[-1])
        ma60 = float(close.rolling(60).mean().iloc[-1])
        # 排列强度:多头排列为正、空头为负,连续
        trend = ((ma5 - ma20) / (ma20 + 1e-9)) * 0.5 + ((ma20 - ma60) / (ma60 + 1e-9)) * 0.5

        # === 因子 3:量价配合(带量的涨跌)===
        recent_vol = float(volume.iloc[-5:].mean())
        avg_vol = float(volume.iloc[-60:].mean())
        vol_ratio = recent_vol / avg_vol if avg_vol > 0 else 1.0
        px_chg = float(close.iloc[-1] / close.iloc[-5:].mean() - 1)
        volume_price = px_chg * min(vol_ratio, 3.0) / 3.0

        # === 因子 4:波动率(越低越好 → 取负号统一为"越大越好")===
        returns = close.pct_change().dropna()
        vol = float(returns.std()) if len(returns) > 1 else 0.0
        volatility = -vol

        # === 因子 5:均值回归(相对 20 日均线的 z 值,越负越加分)===
        sd20 = float(close.rolling(20).std().iloc[-1])
        z = (float(close.iloc[-1]) - float(ma20)) / sd20 if sd20 > 0 else 0.0
        mean_reversion = -z

        return {
            "momentum": momentum,
            "trend": trend,
            "volume_price": volume_price,
            "volatility": volatility,
            "mean_reversion": mean_reversion,
        }

    @staticmethod
    def _cross_sectional_normalize(
        raws: list[dict[str, float]],
    ) -> list[dict[str, float]]:
        """横截面百分位归一化:每个因子在当期 universe 内取排名 → [0,1]

        保证任何分布下都保留区分度,不再出现"±5% 之外全压成 0/1"。
        全部相等时返回 0.5(无法区分)。
        """
        if not raws:
            return []
        keys = list(raws[0])
        out = [dict.fromkeys(keys, 0.5) for _ in raws]
        n = len(raws)
        for k in keys:
            values = [r[k] for r in raws]
            lo, hi = min(values), max(values)
            if hi - lo < 1e-12:
                continue  # 全同 → 保持 0.5
            for i, v in enumerate(values):
                # 严格小于的个数 / (n-1) → 百分位,单调且铺满 [0,1]
                rank = sum(1 for w in values if w < v)
                out[i][k] = rank / (n - 1)
        return out

    def _build_pick(
        self, symbol: str, _fallback: float, factors: dict[str, float]
    ) -> "StockPick | None":
        """由归一化因子构造最终推荐"""
        weights = WEIGHTS
        score = sum(factors[k] * weights[k] for k in factors)

        if score >= 0.65:
            direction = "buy"
        elif score <= 0.40:
            direction = "sell"
        else:
            direction = "hold"

        confidence = abs(score - 0.5) * 2

        rationale = self._make_rationale(symbol, factors, weights, score)

        return StockPick(
            symbol=symbol,
            score=round(score, 3),
            direction=direction,
            confidence=round(confidence, 3),
            rationale=rationale,
            factors={k: round(v, 4) for k, v in factors.items()},
        )

    def _normalize_score(self, value: float, scale: float = 0.05) -> float:
        """归一化到 [0, 1]"""
        # 假设 value ∈ [-0.3, 0.3] 比较合理
        normalized = 0.5 + value / (2 * scale)
        return max(0.0, min(1.0, normalized))

    def _make_rationale(
        self,
        symbol: str,
        factors: dict[str, float],
        weights: dict[str, float],
        score: float,
    ) -> str:
        """自然语言解释(规则版)"""
        sorted_factors = sorted(factors.items(), key=lambda x: x[1], reverse=True)
        top_factor = sorted_factors[0]
        bottom_factor = sorted_factors[-1]

        lines = [f"📊 {symbol} 综合评分 {score:.2f}"]
        lines.append(f"  ✅ 主要加分: {top_factor[0]}={top_factor[1]:.2f} (权重{weights[top_factor[0]]:.0%})")
        lines.append(f"  ⚠️  主要减分: {bottom_factor[0]}={bottom_factor[1]:.2f} (权重{weights[bottom_factor[0]]:.0%})")

        # 强信号
        if factors["trend"] >= 0.7:
            lines.append("  📈 多头排列,趋势向上")
        elif factors["trend"] <= 0.3:
            lines.append("  📉 空头排列,趋势向下")

        if factors["momentum"] >= 0.7:
            lines.append("  🚀 动量强劲,过去 20/60 日涨幅明显")
        elif factors["momentum"] <= 0.3:
            lines.append("  🐌 动量疲弱,近期下跌")

        if factors["volume_price"] >= 0.7:
            lines.append("  💰 放量上涨,资金流入")
        elif factors["volume_price"] <= 0.3:
            lines.append("  ⚠️  放量下跌,资金流出")

        return "\n".join(lines)

    def _get_kline(self, symbol: str, as_of: str | None) -> Optional["pd.DataFrame"]:
        """从 DuckDB 拉 K 线"""
        try:
            with self.db as db:
                if as_of:
                    df = db.query_df(
                        "SELECT * FROM kline_daily WHERE symbol = ? AND date <= ? ORDER BY date DESC LIMIT 100",
                        [symbol, as_of],
                    )
                else:
                    df = db.query_df(
                        "SELECT * FROM kline_daily WHERE symbol = ? ORDER BY date DESC LIMIT 100",
                        [symbol],
                    )
                return df if not df.empty else None
        except Exception as e:
            logger.warning("kline_query_failed", symbol=symbol, error=str(e))
            return None
