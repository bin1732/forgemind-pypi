<div align="center">

# 🧠 ForgeMind

**AI-Powered Quantitative Research & Trading Agent Framework**

*Build, test, and deploy quantitative strategies with AI agents — no 50-engineer team required.*

</div>

<div align="center">

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python](https://img.shields.io/badge/Python-3.11+-green.svg)](https://www.python.org/downloads/)
[![Tauri](https://img.shields.io/badge/Tauri-2.x-orange.svg)](https://tauri.app/)
[![Stars](https://img.shields.io/github/stars/bin1732/forgemind?style=social)](https://github.com/bin1732/forgemind)

[English](README.md) · Apache-2.0

</div>

---

## ✨ Features

| | |
|---|---|
| **169 Alpha Factors** | Alpha158 (152) · Alpha101 (11) · Barra 风险模型 · IC 监控 |
| **Stock Screening Agent** | Multi-factor scoring + AI rationale generation |
| **Backtest Engine** (`forgemind backtest`) | Event-driven 事件驱动 · 3 种滑点模型(fixed / linear / sqrt) · 17 策略(`forgemind backtest --list-strategies` 看全部) |
| **AI Decision Agent** | LangGraph 6-node pipeline · 9 LLM providers · 人工审批 gating |
| **Desktop App** | Tauri 2.x · Next.js 15 frontend · MCP protocol (Claude Desktop / Cursor) — 需本机已装 Python 3.11+ 与本包(桌面端启动 Python sidecar,未捆绑解释器) |
| **Free Data** | AKShare · A-shares + CN macro(PMI / CPI / PPI / M2 / 国债收益率 / 汇率)· DuckDB · *(US 需配置 FORGEMIND_US_TOKEN,见 `forgemind info`)* |

---



## 📦 Install

```bash
# 从 GitHub Pages 索引安装
#
# 必须是 --extra-index-url,不是 --index-url:
#   --index-url 会**替换**默认源,于是 fastapi / duckdb 这些依赖也去
#   我们的索引里找,结果全部 "No matching distribution found"。
#   --extra-index-url 是在默认源(PyPI)旁边**追加**我们的索引,依赖照常
#   从 PyPI 解析,forgemind 本体从我们的索引拿。
#
# 同理,地址是 /pypi/simple/,**不要**再带 /forgemind/ ——
# pip 会自动拼接项目名,写成 .../simple/forgemind/ 时它实际请求
# .../simple/forgemind/forgemind/ 得到 404。
pip install --extra-index-url https://bin1732.github.io/forgemind-pypi/pypi/simple/ forgemind

# 需要 A 股数据源(forgemind etl)时,加 [cn] extra:
pip install --extra-index-url https://bin1732.github.io/forgemind-pypi/pypi/simple/ "forgemind[cn]"
```

> 验证方式:以上两条命令在全新 venv 中已验证通过 —— `--extra-index-url` 形式
> 能同时解析 forgemind 本体与全部依赖,`forgemind[cn]` 额外装上 akshare。
> 也可直接装文件:从上面的下载页取 `forgemind-<版本>-py3-none-any.whl` 再 `pip install` 它。

或直接下载单文件二进制(Linux / macOS / Windows,见 Releases)。

启动本地 API 服务:

```bash
python -m forgemind.api.main --port 8000
```

**Requirements:** Python 3.11+ · AKShare (free data) · Optional: OpenAI / Anthropic API key

**Optional services:** ClickHouse / PostgreSQL / Redis / NATS 是多租户生产环境的可选项,本地单机跑 DuckDB 即可。`/api/v1/health/services` 会报这些 service 的连接状态 —— **未连接不影响** `forgemind etl / pick / backtest / agent / mcp` 任何子命令。

---

## 🔬 Research Pipeline(API / Tauri 桌面端)

`forgemind backtest` 跑的是事件驱动回测。完整研究流水线(**Walk-Forward Optimization · Monte Carlo 稳健性 · 多因子 IC 评估 · LightGBM 训练**)在 `POST /api/v1/pipeline/run`(Tauri 桌面端专用)与 `forgemind.core.pipeline.EndToEndPipeline` Python SDK 中提供;CLI 子命令未单独暴露。

## 🔌 接入 MCP 客户端(Claude Desktop / Cursor / Claude Code)

`forgemind mcp` 以 stdio 方式提供 9 个 MCP 工具。客户端需要一个**绝对路径**
的命令 —— MCP 客户端不会用你当前 shell 的 PATH。

**1. 确认 `forgemind` 在哪**

```bash
which forgemind     # macOS/Linux
where forgemind     # Windows
```

**2. 写进客户端配置**

`claude_desktop_config.json`(macOS:
`~/Library/Application Support/Claude/`;Windows:
`%APPDATA%\Claude\`):

```json
{
  "mcpServers": {
    "forgemind": {
      "command": "/abs/path/to/forgemind",
      "args": ["mcp"],
      "env": { "PYTHONUNBUFFERED": "1" }
    }
  }
}
```

Cursor / Claude Code 等把 `mcpServers` 放在各自配置里,结构相同。

**3. 验证连上了**

客户端里问一句"列一下 forgemind 有哪些工具",或直接手动握手:

```bash
echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"probe","version":"1"}}}' \
  | forgemind mcp
```

应回 `{"jsonrpc":"2.0","id":1,"result":{"serverInfo":{"name":"forgemind",...}}}`

> **用真实数据**:客户端里的 `get_kline` / `stock_pick` / `check_ic_decay`
> 读的是本地 DuckDB,得先跑过一次 `forgemind etl`,否则会如实返回
> "本地没有行情数据"。

---

## 🚀 Quick Start

```python
from forgemind.core.agents.stock_picker import StockPickerAgent
from forgemind.core.data.akshare_etl import AKShareETL
from forgemind.core.backtest.engine import SimpleBacktestEngine

# 1. Pull free A-share data
etl = AKShareETL()
await etl.run(symbols=["600519", "000001"], start="2024-01-01")

# 2. Screen with multi-factor agent
picker = StockPickerAgent()
picks = await picker.pick(universe=["600519", "000001"], top_n=5)

# 3. Backtest
from forgemind.core.strategies.base import MovingAverageCrossStrategy
engine = SimpleBacktestEngine(initial_capital=100_000)
result = engine.run(MovingAverageCrossStrategy(), price_df)
print(result.sharpe, result.total_return, result.max_drawdown)

# 4. AI decision (Claude / GPT / Ollama)
from forgemind.core.agents.portfolio_context import run_decision
state = await run_decision(symbol="600519.SH", portfolio=PortfolioContext(...))
```

Or via CLI:

```bash
# etl / pick 需要 A 股数据源,先确保装了 [cn] extra(akshare)
forgemind etl --symbols 600519,000001 --start 2024-01-01
forgemind pick --top-n 5
forgemind backtest --strategy ma_cross
forgemind agent --symbol 600519.SH
```

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   ForgeMind                             │
├──────────────┬──────────────────┬─────────────────────┤
│ CLI / API    │ Desktop (Tauri)  │ MCP Protocol        │
├──────────────┴──────────────────┴─────────────────────┤
│  FastAPI Server                                         │
├───────────────┬───────────────┬───────────────────────┤
│ Stock Picker  │ AI Decision   │ Backtest Engine       │
│ Agent         │ (LangGraph)   │ (Event-driven)        │
├───────────────┴───────────────┴───────────────────────┤
│  169 Alpha Factors (Alpha158 + Alpha101) · IC · Barra   │
├─────────────────────────────────────────────────────────┤
│  AKShare ETL → DuckDB / ClickHouse                      │
└─────────────────────────────────────────────────────────┘
```

---

## 🤖 LLM Providers

**9 providers** with automatic fallback:

> OpenAI · Anthropic · Google Gemini · DeepSeek · Qwen · Mistral · Ollama · vLLM · LM Studio

Default fallback chain: Claude → GPT → Gemini → DeepSeek → Ollama.

---

## 📡 Signals

ForgeMind outputs trading signals — it does **not** connect to brokers. Use the signal JSON with your own execution layer (vnpy · nautilus_trader · broker SDK).

```json
{
  "signal_id": "sig_20260919_141532_600519.SH",
  "symbol": "600519.SH",
  "side": "BUY",
  "confidence": 0.78,
  "rationale": "Multi-agent consensus: fundamentals 4/5, technical 3/5, sentiment 5/5",
  "timestamp": "2026-09-19T14:15:32Z",
  "execution": "USER_RESPONSIBILITY"
}
```

---

## ❓ FAQ

<details>
<summary><b>Q: 安装时报 "No matching distribution found" 怎么办?</b></summary>

A: 检查你用的是 `--extra-index-url` 不是 `--index-url`:

```bash
# ✅ 正确 — 默认源 (PyPI) 仍可用,只有 forgemind 走我们的索引
pip install --extra-index-url https://bin1732.github.io/forgemind-pypi/pypi/simple/ forgemind

# ❌ 错误 — 会替换默认源,fastapi / duckdb 也去我们的索引里找 → 全部失败
pip install --extra-index-url https://bin1732.github.io/forgemind-pypi/pypi/simple/ forgemind
```

URL 路径是 `/pypi/simple/`,**不要**再加 `/forgemind/`。
</details>

<details>
<summary><b>Q: 桌面端启动报 "Python sidecar 未运行" 怎么办?</b></summary>

A: 桌面端 (Tauri) spawn Python sidecar (forgemind.api.main),需要:
1. 系统已装 Python 3.11+
2. 已 `pip install forgemind` (不是只装桌面端安装包)
3. PATH 里能找到 `forgemind` 命令

验证: 终端跑 `forgemind info` 应输出版本号和 DuckDB 路径。
</details>

<details>
<summary><b>Q: ETL 拉到 0 条数据 / 标的取不到怎么办?</b></summary>

A: 检查:

```bash
# 1. 标的代码格式: 6 位纯数字 (600519),不要带 .SH/.SZ
forgemind etl --symbols 600519,000001 --start 2024-01-01 --end 2024-12-31

# 2. 日期范围不能太短 (建议至少 1 年才有 IC 统计意义)

# 3. 网络可达: akshare 走东方财富 / 腾讯 / 新浪,任一可达即可
```

退出码含义见下表。
</details>

<details>
<summary><b>Q: `forgemind backtest` 报 "symbol 不在 DuckDB" 怎么办?</b></summary>

A: 先跑 ETL 把标的 K 线拉下来:

```bash
forgemind etl --symbols 600519 --start 2022-01-01 --end 2024-12-31
forgemind backtest --symbol 600519 --start 2024-01-01 --end 2024-12-31
```

`forgemind backtest` 默认 DuckDB 真数据优先;如果库里没数据,会用模拟数据并在报告里标 "数据来源: 模拟"。
</details>

<details>
<summary><b>Q: US 股票数据 / 因子怎么没出来?</b></summary>

A: README "Free Data" 列了 US,但实际上 US 数据源全部需要 token (无免费不限流源):

```bash
export FORGEMIND_US_TOKEN=your_alpha_vantage_or_polygon_key
forgemind etl --symbols AAPL --start 2024-01-01 --end 2024-12-31
```

没 token 跑会得到 "US 行情源未配置" 错误。`forgemind info` 显示当前 US 数据源状态。
</details>

<details>
<summary><b>Q: 多个 test 一起跑就报 "Unique file handle conflict",分开跑又没事?</b></summary>

A: 这是 DuckDB 同 path 多个 read_only + read_write 连接的已知限制。ForgeMind 用 `@lru_cache` 持有一个长连接,测试 conftest 已统一改 rw。如果你自己写 test:

```python
import forgemind.core.data.storage as sm
sm._DUCKDB_CONN_CACHE.clear()  # 验证前清掉
con = duckdb.connect(db_path)  # 不要再用 read_only=True
```
</details>

## 🛑 错误码速查表

| 退出码 | 类别 | 触发场景 | 建议动作 |
|---|---|---|---|
| 0 | 成功 | 正常完成 | - |
| 1 | 一般错误 | argparse 参数错 / 用户中断 (Ctrl+C) | 检查参数 / 重跑 |
| 2 | 资源类 | `MemoryError` (标的 × 区间一次装不下) | 缩小范围分批跑 |
| 3 | 数据/上游类 | `TimeoutError` (上游无响应) / 0 bars (取数失败) | 重试或换源 |
| 4 | 资源类 | `OSError errno=28` (磁盘 ENOSPC) | 清理磁盘 |
| 5+ | 业务类 | signal / agent human-approval 拒绝 | 显式 `--yes` 跳过 |

举例:
```bash
$ forgemind etl --symbols 600519 --start 2024-01-01 --end 2024-12-31
# 上游 timeout
# 退出码: 3
# 重试: forgemind etl --symbols 600519 --start 2024-01-01 --end 2024-12-31

$ forgemind agent --symbol 600519.SH
# 等待人工审批
# 退出码: 5
# 重试: forgemind agent --symbol 600519.SH --yes  # 跳过审批,真落 snapshot
```

---

## 🧪 Tests

```bash
pytest tests/ -v
# 648 test files · 10110 tests

# 常规档位:真实业务用例,起真实子进程与真实数据库
pytest tests/ -m "not heavy"
# 8273 cases

# 重并发档位:百万级真实运算,单独用更宽的超时执行
pytest tests/ -m heavy
# 1837 cases
```

重并发档的规模就是设计意图,流水线上的机器跑不完全部用例,这一档在
流水线上按文件分组抽样执行,每个文件仍有代表被执行,代码路径不漏;
规模本身由本地与专用环境验证。

流水线上的常规档位当前为 7408 通过、84 跳过,源码覆盖率 67%。

---

## 🤝 Contributing

PRs welcome. Please run `pre-commit run --all-files` before submitting.

---

## 📄 License

[Apache License 2.0](LICENSE) · Copyright 2026 灵感引擎工坊 (bin1732)
test
test
