"""
CommandPalette 之前 7 个命令(action)全是 alert("...") toast,按 ⌘R 弹个
"启动端到端流水线..." 没有任何真后端调用。

底层修法:每个 action 改成调 MCP tool / Rust command,出错真实告警。
本测试防止 alert(...) 复活 —— 7 个命令必须调用 call / mcpTool,
绝不能只是 alert 文本提示。
"""
from pathlib import Path
import re

REPO = Path(__file__).resolve().parents[1]
PALETTE = REPO / "forgemind-ui" / "components" / "command-palette.tsx"

# 这些命令 id 必须存在 + 它们的 action 必须非 alert-only
COMMAND_IDS = [
    "run-pipeline",
    "compute-factors",
    "evaluate-ic",
    "train-lgbm",
    "walk-forward",
    "monte-carlo",
    "stock-pick",
    "fetch-akshare",
]


def test_command_palette_no_alert_only_actions():
    """每个命令的 action 不能只是 alert() —— 必须调 call/mcpTool 真后端

    简单粗暴的判断:action 体里出现 call( 或 mcpTool(,且只在 fetch-akshare
    例外(ETL 是 CLI 长任务,没对应 MCP)。
    """
    src = PALETTE.read_text(encoding="utf-8")
    for cmd_id in COMMAND_IDS:
        if cmd_id == "fetch-akshare":
            # ETL 是 CLI 长任务,没 MCP 对应。允许 alert 提示用户去终端跑
            continue
        pattern = rf'id:\s*"{cmd_id}"(.{{0,800}})'
        m = re.search(pattern, src, re.DOTALL)
        if not m:
            raise AssertionError(f"command-palette 找不到 {cmd_id} 命令")
        body = m.group(1)
        # "call<unknown>(cmd, ...)" / "mcpTool<unknown>(cmd, ...)" 都算
        # (TypeScript 泛型语法:capture(<T>))
        import re as _re
        has_call = bool(_re.search(r"call\s*<[^>]+>\s*\(", body)) or ("call(" in body)
        has_mcp = bool(_re.search(r"mcpTool\s*<[^>]+>\s*\(", body)) or ("mcpTool(" in body)
        assert has_call or has_mcp, (
            f"command-palette 的 {cmd_id} action 仅 alert,没调真后端;"
            " 应该用 mcpTool() / call() 触发 MCP / Rust command"
        )


def test_command_palette_imports_mcp_bridge():
    """command-palette 必须 import mcpTool + call 才能接通真后端"""
    src = PALETTE.read_text(encoding="utf-8")
    assert "mcpTool" in src, "command-palette 没 import mcpTool"
    assert 'from "@/lib/tauri"' in src, "command-palette 没 import tauri 桥"
