# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifi    _classify_fetch_error = staticmethod(_classify_fetch_error)
import asyncio

import pandas as pd

from forgemind.core.data.storage import DuckDBStorage
from forgemind.core.observability.logging import get_logger

logger = get_logger("forgemind.akshare_etl")


def _classify_fetch_error(exc: Exception) -> str:
    """把取数异常归类成用户可行动的几种原因

    必须是**模块级**函数:AKShareETL.run 在初始化阶段也要用它,
    只挂在 AKShareDataSource 上的话会 AttributeError —— 保护代码自己
    抛错比不保护更糟。
    """
    msg = str(exc).lower()
    etype = type(exc).__name__
    # 类型比消息可靠:ConnectionError("reset") 的消息里根本没有
    # "connection" 字样,只看文本会把它误判成 unclassified
    if isinstance(exc, (ConnectionError, TimeoutError)):
        return "network_unreachable"
    if isinstance(exc, PermissionError) or "permission" in msg or "errno 13" in msg:
        return "storage_permission_denied"
    if "no space" in msg or "disk full" in msg or "errno 28" in msg:
        return "storage_full"
    # DuckDB 并发写分类:
    # ConstraintException → 只有 PK/UNIQUE 冲突是并发,其它(NOT NULL / CHECK)
    #   不归 storage_locked(可能是数据 bug,不是锁的问题)
    # TransactionException → 几乎总是 commit 时的并发冲突
    # IOException → 只有消息里含 lock/flock 字样才算锁;
    #   "Cannot read from file" / "disk full" 这种不算
    if etype == "ConstraintException":
        if ("primary key" in msg or "unique constraint" in msg
                or "duplicate key" in msg):
            return ("storage_locked(另一个进程或线程正占用 DuckDB 文件,"
                    "多半是 API 服务、另一个 ETL、pick、agent 同时在写;"
                    "先停掉其它进程再重试,或用 FORGEMIND_DATA_DIR "
                    "指向另一个目录)")
    if etype == "TransactionException":
        return ("storage_locked(并发事务提交失败 —— 另一个进程或线程正"
                "在写同一 DuckDB 文件;先停掉其它进程再重试,或用 "
                "FORGEMIND_DATA_DIR 指向另一个目录)")
    if etype == "IOException" and (
        "lock" in msg or "could not set lock" in msg
        or "conflict" in msg
    ):
        return ("storage_locked(DuckDB 文件级 flock 失败 —— 另一进程正在"
                "读或写;用 FORGEMIND_DATA_DIR 指向另一个目录)")
    if "ioexception" in etype.lower() or isinstance(exc, OSError):
        if "lock" in msg or "could not set lock" in msg or "conflict" in msg:
            return ("storage_locked(另一个进程正占用 data/duckdb/main.db,"
                    "多半是 API 服务或另一个 CLI 还在运行;关掉它,或用 "
                    "FORGEMIND_DATA_DIR 指向另一个目录)")
    if any(k in msg for k in ("connection", "timed out", "timeout",
                              "resolve", "ssl", "max retries",
                              "reset by peer", "aborted")):
        return "network_unreachable"
    if any(k in msg for k in ("json", "decode", "expecting value")):
        return "upstream_returned_non_json(可能限流或被拦截)"
    if isinstance(exc, ModuleNotFoundError):
        return "akshare_not_installed"
    if "invalid" in msg and "symbol" in msg:
        return "invalid_symbol_format"
    if any(k in msg for k in ("too many", "rate", "频繁")):
        return "rate_limited"
    return f"unclassified:{type(exc).__name__}"

class AKShareDataSource:
    """
    AKShare 免费数据源

    用法:
        async with AKShareDataSource() as ds:
            df = await ds.get_history("600519.SH", start="2024-01-01", end="2024-12-31")
    """

    def __init__(self):
        self._akshare = None
        #: 最近一次取数失败的原因分类(None = 尚无失败)
        self._last_error: str | None = None
        logger.info("akshare_init")

    async def __aenter__(self):
        try:
            import akshare as ak
            self._akshare = ak
            logger.info("akshare_loaded")
        except ImportError:
            logger.warning(
                "akshare_not_installed",
                hint="pip install 'forgemind[cn]'",
            )
            self._akshare = None
        return self

    async def __aexit__(self, *args):
        pass

    async def get_stock_list(self) -> pd.DataFrame:
        """拉 A 股全列表"""
        if not self._akshare:
            return pd.DataFrame()
        try:
            # stock_info_a_code_name — A 股代码 + 名称
            df = self._akshare.stock_info_a_code_name()
            df = df.rename(columns={
                "code": "symbol",
                "name": "name",
            })
            logger.info("akshare_stock_list_loaded", count=len(df))
            return df
        except Exception as e:
            logger.error("akshare_stock_list_failed", error=str(e))
            return pd.DataFrame()

    @staticmethod
    def _classify_fetch_error(exc: Exception) -> str:
        """把取数异常归类成用户可行动的几种原因"""
        msg = str(exc).lower()
        if "connection" in msg or "timed out" in msg or "timeout" in msg \
                or "resolve" in msg or "ssl" in msg or "max retries" in msg:
            return "network_unreachable"
        if "json" in msg or "decode" in msg or "expecting value" in msg:
            return "upstream_returned_non_json(可能限流或被拦截)"
        if isinstance(exc, ModuleNotFoundError):
            return "akshare_not_installed"
        if "invalid" in msg and "symbol" in msg:
            return "invalid_symbol_format"
        if "too many" in msg or "rate" in msg or "频繁" in msg:
            return "rate_limited"
        return f"unclassified:{type(exc).__name__}"

    async def get_history(
        self,
        symbol: str,
        start: str = "2024-01-01",
        end: str = "2024-12-31",
        adjust: str = "qfq",  # 前复权
        period: str = "daily",
    ) -> pd.DataFrame:
        """
        拉历史 K 线

        Args:
            symbol: 股票代码(6 位数字,如 "600519")
            start: 开始日期
            end: 结束日期
            adjust: qfq 前复权 / hfq 后复权 / "" 不复权
            period: daily / weekly / monthly

        Returns:
            DataFrame(date, symbol, open, high, low, close, volume)
        """
        if not self._akshare:
            self._last_error = "akshare_not_installed"
            return pd.DataFrame()

        start_fmt = start.replace("-", "")
        end_fmt = end.replace("-", "")

        # 多源回退
        #
        # 修正前:只调用东财 stock_zh_a_hist 一家。而东财对**境外 IP**
        # 会直接重置连接(已验证 JSONDecodeError),于是这些网络环境下的用户
        # 一条 K 线都拉不到。已验证新浪/腾讯两家在同样环境下完全可用。
        # 单一数据源不该是可用性前提。
        last_err: Exception | None = None
        for provider, fetch in self._history_providers(symbol, start_fmt, end_fmt,
                                                        adjust, period):
            try:
                df = fetch()
            except Exception as exc:
                last_err = exc
                logger.warning(
                    "akshare_provider_failed",
                    symbol=symbol, provider=provider,
                    error_type=type(exc).__name__,
                )
                continue
            if df is None or df.empty:
                last_err = None  # 该源可用但区间内无数据,不必换源
                break
            df = self._normalize_history(df, symbol)
            # 记下这一行数据来自哪个源。三个源的"前复权"基准并不一致
            # (已验证茅台 2024 年 6 月分红后,腾讯与新浪的历史收盘价最大差
            # 1.41%),所以回退链会在同一张表里混进两套价格约定。
            # 不落库的话,这种混用完全不可见 —— 因子值和回测结果会随
            # "今天哪个源可用"而漂移。
            df.attrs["provider"] = provider
            logger.info(
                "akshare_history_loaded",
                symbol=symbol, provider=provider, start=start, end=end, n=len(df),
            )
            return df

        reason = (
            _classify_fetch_error(last_err) if last_err
            else "empty_result(所有源均返回空,可能是代码无数据或日期区间为空)"
        )
        self._last_error = reason
        logger.error(
            "akshare_history_failed",
            symbol=symbol,
            error_type=type(last_err).__name__ if last_err else "EmptyData",
            reason=reason,
        )
        return pd.DataFrame()

    def _history_providers(self, symbol, start_fmt, end_fmt, adjust, period):
        """按可用性排序的取数源:(名称, 调用)"""
        ak = self._akshare
        ak_name = self._exchange_prefixed(symbol)
        return [
            ("eastmoney", lambda: ak.stock_zh_a_hist(
                symbol=symbol, period=period,
                start_date=start_fmt, end_date=end_fmt, adjust=adjust)),
            ("tencent", lambda: ak.stock_zh_a_hist_tx(
                symbol=ak_name, start_date=start_fmt, end_date=end_fmt, adjust=adjust)),
            ("sina", lambda: ak.stock_zh_a_daily(
                symbol=ak_name, start_date=start_fmt, end_date=end_fmt, adjust=adjust)),
        ]

    @staticmethod
    def _exchange_prefixed(symbol: str) -> str:
        """600519 -> sh600519 / 000001 -> sz000001(新浪/腾讯的代码格式)"""
        s = str(symbol).strip().lower()
        if s.startswith(("sh", "sz", "bj")):
            return s
        head = s[:1]
        if symbol.isdigit() and len(s) == 6:
            prefix = "sh" if head in "5679" else "sz"
            return prefix + s
        return s

    @staticmethod
    def _normalize_history(df: "pd.DataFrame", symbol: str) -> "pd.DataFrame":
        """把不同源的列名统一成 date/open/high/low/close/volume"""
        import pandas as _pd

        df = df.rename(columns={
            "日期": "date", "开盘": "open", "最高": "high", "最低": "low",
            "收盘": "close", "成交量": "volume", "成交额": "amount",
        })
        # 腾讯/新浪用英文列名时做一次兜底
        df.columns = [str(c).lower() for c in df.columns]
        if "date" in df.columns:
            df["date"] = _pd.to_datetime(df["date"]).dt.date
        df["symbol"] = symbol
        want = ["date", "symbol", "open", "high", "low", "close", "volume"]
        for c in want:
            if c not in df.columns:
                df[c] = None
        df = df[want]
        if df["date"].isna().any():
            df = df.dropna(subset=["date"])
        return df


class AKShareETL:
    """
    AKShare ETL — 把数据落到 DuckDB

    用法:
        etl = AKShareETL()
        await etl.run(symbols=["600519", "000001"], days=365)
    """

    def __init__(self, storage: DuckDBStorage | None = None):
        self.storage = storage or DuckDBStorage()
        logger.info("akshare_etl_init")

    async def init_tables(self):
        """初始化 DuckDB 表"""
        with self.storage as db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS stock_list (
                    symbol VARCHAR PRIMARY KEY,
                    name VARCHAR
                )
            """)
            db.execute("""
                CREATE TABLE IF NOT EXISTS kline_daily (
                    date DATE,
                    symbol VARCHAR,
                    open DOUBLE,
                    high DOUBLE,
                    low DOUBLE,
                    close DOUBLE,
                    volume BIGINT,
                    provider VARCHAR,
                    PRIMARY KEY (date, symbol)
                )
            """)
            # 老库没有 provider 列,补上;补不上的要报出来,不能静默
            cols = set(db.query_df(
                "SELECT * FROM kline_daily LIMIT 0").columns)
            if "provider" not in cols:
                db.execute("ALTER TABLE kline_daily ADD COLUMN provider VARCHAR")
                logger.info("akshare_etl_provider_column_added")
            db.execute("CREATE INDEX IF NOT EXISTS idx_kline_symbol ON kline_daily(symbol, date)")
            logger.info("akshare_etl_tables_created")

    async def run(
        self,
        symbols: list[str],
        start: str = "2024-01-01",
        end: str = "2024-12-31",
        batch_size: int = 10,
    ) -> dict[str, int]:
        """
        跑 ETL

        Args:
            symbols: 股票代码列表(6 位数字)
            start: 开始日期
            end: 结束日期
            batch_size: 每批多少(防限流)
        """
        # 建表/初始化也可能因磁盘、上游握手等失败,必须一并纳入失败分类,
        # 否则用户看到的是裸堆栈而不是可行动的提示
        try:
            await self.init_tables()
        except Exception as exc:
            reason = _classify_fetch_error(exc)
            logger.error("akshare_etl_init_failed", reason=reason,
                         error_type=type(exc).__name__)
            return {"stocks": 0, "klines": 0, "ok_symbols": 0,
                    "failures": {f"init:{reason}": 1}}

        report: dict[str, int] = {}
        failures: dict[str, int] = {}

        async with AKShareDataSource() as ds:
            # 1. 股票列表
            try:
                stock_list = await ds.get_stock_list()
            except Exception as exc:
                # 拿不到代码表不该中断:历史 K 线仍可拉
                logger.warning("akshare_stock_list_failed",
                               error_type=type(exc).__name__)
                stock_list = pd.DataFrame()
            if not stock_list.empty:
                with self.storage as db:
                    for _, row in stock_list.iterrows():
                        db.execute(
                            "INSERT OR REPLACE INTO stock_list (symbol, name) VALUES (?, ?)",
                            [row["symbol"], row["name"]],
                        )

            # 2. 历史 K 线
            for i in range(0, len(symbols), batch_size):
                batch = symbols[i : i + batch_size]
                logger.info(
                    "akshare_etl_batch",
                    batch=i // batch_size + 1,
                    n=len(batch),
                )

                for symbol in batch:
                    df = await ds.get_history(symbol, start, end)
                    if df.empty:
                        # 记录该标的失败数与原因,不再静默跳过
                        reason = ds._last_error or "empty_result(可能是代码无数据或日期区间为空)"
                        failures[reason] = failures.get(reason, 0) + 1
                        continue
                    report[symbol] = len(df)

                    provider = df.attrs.get("provider", "unknown")
                    n_inserted = 0
                    n_failed = 0
                    last_insert_err: Exception | None = None
                    with self.storage as db:
                        for _, row in df.iterrows():
                            # INSERT 必包 try/except:并发或磁盘异常不应
                            # 让整个 ETL 静默丢数据。ConstraintException /
                            # TransactionException 都被 _classify_fetch_error
                            # 转成 actionable 的 storage_locked。
                            try:
                                db.execute(
                                    """INSERT OR REPLACE INTO kline_daily
                                    (date, symbol, open, high, low, close, volume, provider)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                                    [
                                        row["date"], row["symbol"],
                                        row["open"], row["high"],
                                        row["low"], row["close"],
                                        row["volume"], provider,
                                    ],
                                )
                                n_inserted += 1
                            except Exception as insert_exc:  # noqa: BLE001
                                n_failed += 1
                                last_insert_err = insert_exc

                    if n_failed:
                        reason = _classify_fetch_error(
                            last_insert_err) if last_insert_err else "unknown"
                        failures[reason] = failures.get(reason, 0) + n_failed
                        # 报告里只记「真成功写入的」条数,免得用户看 len(df)
                        # 以为全成功
                        report[symbol] = n_inserted
                        logger.warning(
                            "akshare_etl_partial_insert",
                            symbol=symbol, n_inserted=n_inserted,
                            n_failed=n_failed, reason=reason)
                    else:
                        report[symbol] = n_inserted

                    # 防限流
                    await asyncio.sleep(0.5)

            # 3. 统计
            with self.storage as db:
                n_stocks = db.query_scalar("SELECT COUNT(*) FROM stock_list")
                n_klines = db.query_scalar("SELECT COUNT(*) FROM kline_daily")
                logger.info(
                    "akshare_etl_complete",
                    stocks=n_stocks,
                    klines=n_klines,
                    ok_symbols=len(report),
                    failed_symbols=len(failures),
                )
                if failures:
                    logger.warning(
                        "akshare_etl_partial_failure",
                        failures=failures,
                        ok_symbols=len(report),
                    )
                return {
                    "stocks": n_stocks,
                    "klines": n_klines,
                    "ok_symbols": len(report),
                    "failures": failures,
                }
