# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

"""Models — 轻量导入。

此前这里 eager import 了 lightgbm_model / xgboost_model,导致
`from forgemind.core.models.transformer_model import TransformerModel`
也会连带拉起 lightgbm + sklearn + xgboost(已验证 ~4.5s),而 docstring
却声称 "light-weight imports by default" —— 与实际不符。

改为 PEP 562 的模块级 __getattr__ 惰性解析:只有真正取用某个类时
才 import 对应子模块。

    from forgemind.core.models import LightGBMModel   # 此时才加载 lightgbm
    from forgemind.core.models.transformer_model import TransformerModel
"""

from importlib import import_module
from typing import Any

_LAZY = {
    "LightGBMModel": ".lightgbm_model",
    "ModelConfig": ".lightgbm_model",
    "ModelRegistry": ".lightgbm_model",
    "TrainResult": ".lightgbm_model",
    "XGBoostModel": ".xgboost_model",
    "CatBoostModel": ".xgboost_model",
    "EnsembleModel": ".xgboost_model",
    "TransformerModel": ".transformer_model",
    "TransformerTimeSeries": ".transformer_model",
    "PositionalEncoding": ".transformer_model",
}

__all__ = list(_LAZY)


def __getattr__(name: str) -> Any:
    """按需解析:只有访问具体类时才 import 对应子模块"""
    module = _LAZY.get(name)
    if module is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    value = getattr(import_module(module, __name__), name)
    globals()[name] = value  # 缓存,后续直接命中
    return value


def __dir__() -> list[str]:
    return sorted(__all__)
