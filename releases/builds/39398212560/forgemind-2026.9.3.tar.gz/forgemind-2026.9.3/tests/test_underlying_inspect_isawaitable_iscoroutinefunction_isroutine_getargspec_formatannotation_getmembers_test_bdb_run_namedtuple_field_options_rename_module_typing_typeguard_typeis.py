# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0
"""`inspect` 进阶 (isawaitable/iscoroutinefunction/isroutine/ismethod/formatannotation/getargspec/getannotions) + `bdb` 进阶 (run/breakpoint 沙箱 skip) + `namedtuple` 进阶 (field options+rename+_module+_field_defaults) + `typing.TypeGuard/TypeIs` 3.10+/3.13+ + 真底层测试。