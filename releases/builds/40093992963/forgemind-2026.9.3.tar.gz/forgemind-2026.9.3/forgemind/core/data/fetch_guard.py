# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

"""取数调用的超时保护。

第三方行情接口不暴露超时参数,而这些接口在受限网络下可能连接建起来
却不回数据。没有超时的话,一次取数就能把整条流水线挂住 —— 卡住比取
不到更难排查:它既不报错也不结束,用户只能干等。

socket 的默认超时是这里唯一能抓的手柄:调用期间把它设成有限值,连接
读不到数据就会变成一次超时失败,调用结束立刻还原。
"""

from __future__ import annotations

import socket
from typing import Callable, TypeVar

T = TypeVar("T")

#: 取数调用的默认超时秒数
DEFAULT_FETCH_TIMEOUT = 25.0


def call_with_timeout(func: Callable[[], T], timeout: float = DEFAULT_FETCH_TIMEOUT) -> T:
    """带超时的调用。

    超时表现为 socket.timeout(即 TimeoutError 的子类),调用方可以按
    抓取失败处理。
    """
    previous = socket.getdefaulttimeout()
    socket.setdefaulttimeout(timeout)
    try:
        return func()
    finally:
        socket.setdefaulttimeout(previous)
