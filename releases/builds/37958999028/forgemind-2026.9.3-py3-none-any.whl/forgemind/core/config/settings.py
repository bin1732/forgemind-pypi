# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def _pkg_version() -> str:
    """版本号单一真源:包内 __version__ → importlib.metadata 兜底

    关键观察:`from forgemind import __version__` 总是从**当前**
    Python 解释器实际加载的 forgemind 包里取 init.py 字符串:
      - 装 wheel:从 site-packages/forgemind/__init__.py(wheel 内置)
      - 开发模式(源码):从 sys.path 首位源码树里的 forgemind/__init__.py
    这两个必须保持一致(wheel build 脚本要 sed 替换成 pyproject 版本)。

    `importlib.metadata.version()` 只读 dist-info,不能识别源码/已装包的
    差异 —— 它的 fallback 会**优先找到已安装的旧版 dist-info**,
    把运行时实际加载的新代码盖掉。所以 metadata 只能作兜底。

    真用户旅程发现的 bug:装 wheel 的用户看到 dist-info 里 9.0 但
    __init__.py 是 9.3(漏 sed),info 报 9.0 而非 9.3。修法:
    优先读包内 __version__(真实运行的代码),回退 metadata(只用来
    验证 build 脚本是否漏改)。
    """
    try:
        from forgemind import __version__
        return __version__
    except Exception:  # pragma: no cover - 极端导入顺序
        pass
    try:
        from importlib.metadata import version as _im_version
        return _im_version("forgemind")
    except Exception:
        return "unknown"


class Settings(BaseSettings):
    """主配置"""
    model_config = SettingsConfigDict(
        env_prefix="FORGEMIND_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Core
    env: Literal["dev", "staging", "prod"] = "dev"
    mode: Literal["server", "desktop", "cli"] = "server"
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_format: Literal["json", "text"] = "json"
    data_dir: str = "./data"
    version: str = Field(default_factory=lambda: _pkg_version())

    # API
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    api_workers: int = 4
    api_secret_key: str = Field(
        default="dev-only-insecure-key-do-not-use-in-prod!!",
        min_length=32,
    )

    @field_validator("api_secret_key")
    @classmethod
    def _validate_secret_key(cls, v: str, info) -> str:
        """生产环境必须显式设置 API_SECRET_KEY,不能使用 dev 默认值"""
        env = info.data.get("env", "dev")
        dev_default = "dev-only-insecure-key-do-not-use-in-prod!!"
        if env in ("prod", "production") and v == dev_default:
            raise ValueError(
                "生产环境禁止使用 dev 默认 api_secret_key,"
                "请通过 FORGEMIND_API_SECRET_KEY 环境变量设置强随机密钥"
            )
        return v
    api_jwt_alg: str = "HS256"
    api_jwt_expire_hours: int = 24
    api_cors_origins: str | list[str] = Field(default_factory=lambda: "http://localhost:3000,tauri://localhost")

    @field_validator("api_cors_origins", mode="before")
    @classmethod
    def _parse_cors(cls, v):
        if isinstance(v, str):
            return [s.strip() for s in v.split(",") if s.strip()]
        return v

    @field_validator("log_level", mode="before")
    @classmethod
    def _normalize_log_level(cls, v):
        """接受任意大小写的环境变量写法

        修正前:`FORGEMIND_LOG_LEVEL=info`(小写,很常见的写法)会直接
        抛 pydantic ValidationError,用户看到的是一整页堆栈而不是
        "日志级别该写什么"。环境变量大小写不该成为使用门槛。
        """
        if isinstance(v, str):
            return v.strip().upper()
        return v

    # PG
    pg_host: str = "localhost"
    pg_port: int = 5432
    pg_user: str = "forgemind"
    pg_password: str = "forgemind"
    pg_database: str = "forgemind"
    pg_pool_size: int = 10
    pg_max_overflow: int = 20

    # ClickHouse
    ch_host: str = "localhost"
    ch_port: int = 9000
    ch_http_port: int = 8123
    ch_user: str = "forgemind"
    ch_password: str = "forgemind"
    ch_database: str = "forgemind"

    # Valkey
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: str = ""

    # NATS
    nats_url: str = "nats://localhost:4222"
    nats_cluster_name: str = "forgemind-cluster"

    # DuckDB
    duckdb_path: str = "./data/duckdb/main.db"

    # MinIO
    minio_endpoint: str = "localhost:9000"
    minio_access_key: str = "forgemind"
    minio_secret_key: str = "forgemind"
    minio_bucket: str = "forgemind"

    # Vault
    vault_addr: str = "http://localhost:8200"
    vault_token: str = "dev-only-token"

    # LLM
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    anthropic_api_key: str = ""
    qwen_api_key: str = ""
    deepseek_api_key: str = ""
    gemini_api_key: str = ""
    mistral_api_key: str = ""

    # Brokers: ForgeMind 不内置券商 SDK(v1.0 起完全解耦)
    # 用户用 vnpy / nautilus_trader / 自己 broker SDK 执行信号
    # 见 §24 L7 信号输出层

    # Data
    tushare_token: str = ""

    # Feature Store
    feature_ic_alert_threshold: float = 0.02
    feature_offline_online_parity_threshold: float = 0.01

    # Observability
    otel_enabled: bool = True
    otel_endpoint: str = "http://localhost:4317"
    prometheus_port: int = 9090

    # Desktop
    desktop_api_port: int = 8008

    @property
    def pg_dsn(self) -> str:
        return f"postgresql+asyncpg://{self.pg_user}:{self.pg_password}@{self.pg_host}:{self.pg_port}/{self.pg_database}"

    @property
    def redis_url(self) -> str:
        if self.redis_password:
            return f"redis://:{self.redis_password}@{self.redis_host}:{self.redis_port}/{self.redis_db}"
        return f"redis://{self.redis_host}:{self.redis_port}/{self.redis_db}"

    def __repr__(self) -> str:
        return f"<Settings env={self.env} mode={self.mode} version={self.version}>"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """单例 — 整个 app 一份"""
    return Settings()
