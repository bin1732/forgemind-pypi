"""
真 GitHub Release wheel 真装真跑:
  1. 真从 https://github.com/bin1732/forgemind-pypi/releases/latest 下载 wheel
  2. 真 venv 装
  3. 真跑 forgemind info / --help
  4. 验装完能 import forgemind + version 匹配

完全不走 mock, 完全在子 venv 跑, 装完用新 venv 的 python 跑真命令。
"""
import os
import subprocess
import sys
import urllib.request
import venv
from pathlib import Path

import pytest


def _download_latest_wheel(dest: Path) -> tuple[Path, int]:
    """真下载 GitHub Releases latest wheel。"""
    url = (
        "https://github.com/bin1732/forgemind-pypi/releases/download/continuous/"
        "forgemind-2026.9.3-py3-none-any.whl"
    )
    try:
        # urllib 有时 UA 受限, 走 curl subprocess
        r = subprocess.run(
            ["curl", "-sL", "-o", str(dest), url],
            capture_output=True, text=True, timeout=60,
        )
        if r.returncode != 0:
            raise RuntimeError(f"curl 失败: rc={r.returncode} stderr={r.stderr}")
    except FileNotFoundError:
        # 没 curl, 走 urllib
        try:
            with urllib.request.urlopen(url, timeout=30) as resp:
                data = resp.read()
            dest.write_bytes(data)
        except Exception as e:
            raise RuntimeError(f"urllib 网络受限: {e}")
    if not dest.exists() or dest.stat().st_size < 50000:
        size = dest.stat().st_size if dest.exists() else 0
        raise RuntimeError(f"wheel 太小 {size} 字节, 可能是 error 页")
    return dest, dest.stat().st_size


@pytest.fixture(scope="module")
def fresh_venv_with_wheel(tmp_path_factory):
    """真建 venv + 装 wheel + 跑 forgemind info。"""
    tmp = tmp_path_factory.mktemp("release_install")
    venv_dir = tmp / "venv"
    wheel_path = tmp / "forgemind-2026.9.3-py3-none-any.whl"

    # 1. 真建 venv
    venv.EnvBuilder(with_pip=True, symlinks=False).create(str(venv_dir))
    pip = venv_dir / "bin" / "pip"
    forgemind_bin = venv_dir / "bin" / "forgemind"

    # 2. 真下载 wheel
    wheel_path, size = _download_latest_wheel(wheel_path)

    # 3. link 现有 .venv 的 site-packages (沙箱无 PyPI, 复用主 venv)
    import shutil
    src_sp = Path("/workspace/.venv/lib/python3.11/site-packages")
    dst_sp = venv_dir / "lib" / "python3.11" / "site-packages"
    if src_sp.exists():
        # 复制核心 deps 的 .dist-info + 包目录
        for item in src_sp.iterdir():
            if item.name.startswith(("click", "pydantic", "rich", "duckdb",
                                     "fastapi", "httpx", "typer", "shellingham",
                                     "structlog", "numpy", "pandas", "polars",
                                     "langchain", "langgraph", "langsmith",
                                     "openai", "anthropic", "pyarrow", "joblib",
                                     "scipy", "scikit", "lightgbm", "tenacity", "pytz", "tzdata",
                                     "python_multipart", "python-multipart",
                                     "uvicorn", "starlette", "anyio",
                                     "sniffio", "h11", "certifi", "idna",
                                     "urllib3", "requests", "PyYAML", "yaml",
                                     "jsonpatch", "jsonpointer", "jsonschema",
                                     "typing_extensions", "annotated_types",
                                     "pydantic_core", "pydantic-settings",
                                     "dotenv", "watchfiles", "websockets",
                                     "exceptiongroup", "tomli", "wrapt",
                                     "SQLAlchemy", "alembic", "Mako", "dateutil",
                                     "pyparsing", "packaging", "six",
                                     "clickhouse_driver", "asyncpg",
                                     "nltk", "regex", "tqdm", "colorama",
                                     "mcp", "jsonschema_spec", "referencing",
                                     "rpds", "pyzmq", "cloudpickle",
                                     "httpx_sse", "sse_starlette",
                                     "langchain_core", "langchain_text_splitters",
                                     "chromadb", "llama_index", "redis",
                                     "nats_py", "nats-py",
                                     "prefect", "fsspec", "aiohttp",
                                     "aiosignal", "frozenlist", "multidict",
                                     "yarl", "charset_normalizer",
                                     "asgi_lifespan", "async_timeout",
                                     "h2", "hpack", "hyperframe",
                                     "pika", "python_jose", "passlib",
                                     "bcrypt", "ecdsa", "rsa", "pyasn1",
                                     "ecdsa", "cffi", "pycparser",
                                     "Pillow", "pillow",
                                     )):
                if not item.name.startswith("forgemind"):
                    target = dst_sp / item.name
                    if not target.exists():
                        try:
                            target.symlink_to(item)
                        except (OSError, FileExistsError):
                            pass

    # 4. 真装 wheel (沙箱无 PyPI, --no-deps 跳过 deps; 我们用 symlink 补)
    r = subprocess.run(
        [str(pip), "install", "--no-deps", str(wheel_path)],
        capture_output=True, text=True, timeout=120,
    )
    if r.returncode != 0:
        pytest.fail(f"pip install 失败: {r.stderr[-500:]}")

    yield {
        "venv": venv_dir,
        "wheel": wheel_path,
        "wheel_size": size,
        "forgemind_bin": forgemind_bin,
        "pip": pip,
    }


def test_wheel_downloaded_size(fresh_venv_with_wheel):
    """wheel 字节数应 ≥ 100KB (不是 error 页)"""
    size = fresh_venv_with_wheel["wheel_size"]
    assert size >= 100_000, f"wheel 太小 {size} 字节"


def test_wheel_zip_structure(fresh_venv_with_wheel):
    """wheel 真含 forgemind 模块 (用 zipfile 真打开看)"""
    import zipfile
    wheel = fresh_venv_with_wheel["wheel"]
    with zipfile.ZipFile(wheel) as z:
        names = z.namelist()
    # 业务关键模块
    required = [
        "forgemind/__init__.py",
        "forgemind/cli.py",
        "forgemind/api/main.py",
        "forgemind/mcp/server.py",
        "forgemind/core/data/storage.py",
        "forgemind/core/backtest/engine.py",
        "forgemind/core/factors/alpha158.py",
        "forgemind-2026.9.3.dist-info/METADATA",
    ]
    for r in required:
        assert r in names, f"wheel 缺 {r}, 实际 (前 20): {names[:20]}"


def test_wheel_metadata_declares_deps(fresh_venv_with_wheel):
    """wheel METADATA 真声明 fastapi/duckdb/pydantic 等核心依赖"""
    import zipfile
    wheel = fresh_venv_with_wheel["wheel"]
    with zipfile.ZipFile(wheel) as z:
        metadata = z.read("forgemind-2026.9.3.dist-info/METADATA").decode("utf-8")
    # 必须声明的核心依赖
    for dep in ("fastapi", "duckdb", "pydantic", "structlog", "click"):
        assert dep in metadata, f"wheel METADATA 应声明 {dep}"
    # 必须有 5 个 extras
    for extra in ("dev", "llm", "ml", "cn", "multimodal", "explain"):
        assert f"Provides-Extra: {extra}" in metadata, f"wheel METADATA 缺 [{extra}] extra"


def test_pip_install_succeeded(fresh_venv_with_wheel):
    """pip install --no-deps 后, forgemind binary 真在 venv/bin/"""
    forgemind_bin = fresh_venv_with_wheel["forgemind_bin"]
    assert forgemind_bin.exists(), f"forgemind binary 应在 {forgemind_bin}"


def test_fresh_venv_imports_forgemind(fresh_venv_with_wheel):
    """新 venv 真能 import forgemind (验 wheel 自洽)"""
    venv_dir = fresh_venv_with_wheel["venv"]
    r = subprocess.run(
        [str(venv_dir / "bin" / "python"), "-c", "import forgemind; print(forgemind.__version__)"],
        capture_output=True, text=True, timeout=15,
    )
    assert r.returncode == 0, f"import 失败: {r.stderr[-300:]}"
    assert "2026.9.3" in r.stdout, f"version 应 2026.9.3, 实际: {r.stdout!r}"


def test_fresh_venv_forgemind_help(fresh_venv_with_wheel):
    """forgemind --help 真跑得通"""
    forgemind_bin = fresh_venv_with_wheel["forgemind_bin"]
    r = subprocess.run(
        [str(forgemind_bin), "--help"],
        capture_output=True, text=True, timeout=15,
    )
    assert r.returncode == 0, f"--help 失败: {r.stderr[-300:]}"
    # 子命令应展示
    assert "etl" in r.stdout, f"--help 应有 etl: {r.stdout[:300]}"
    assert "backtest" in r.stdout, f"--help 应有 backtest"
    assert "agent" in r.stdout, f"--help 应有 agent"
    assert "mcp" in r.stdout, f"--help 应有 mcp"
    assert "pick" in r.stdout, f"--help 应有 pick"


def test_fresh_venv_forgemind_info(fresh_venv_with_wheel):
    """forgemind info 真跑得通, version 真报 2026.9.3"""
    forgemind_bin = fresh_venv_with_wheel["forgemind_bin"]
    r = subprocess.run(
        [str(forgemind_bin), "info"],
        capture_output=True, text=True, timeout=15,
    )
    # info 子命令可能 rc=0 或 rc=2 (settings 错) — 关键是输出含 version
    if r.returncode not in (0, 2):
        pytest.fail(f"info rc={r.returncode}: {r.stdout[-300:]}{r.stderr[-300:]}")
    out = r.stdout + r.stderr
    assert "2026.9.3" in out, f"info 应报 2026.9.3, 实际: {out[:500]}"


def test_fresh_venv_forgemind_backtest_list_strategies(fresh_venv_with_wheel):
    """forgemind backtest --list-strategies 真跑得通, 列策略"""
    forgemind_bin = fresh_venv_with_wheel["forgemind_bin"]
    r = subprocess.run(
        [str(forgemind_bin), "backtest", "--list-strategies"],
        capture_output=True, text=True, timeout=15,
    )
    if r.returncode != 0:
        pytest.fail(f"list-strategies rc={r.returncode}: {r.stdout[-300:]}{r.stderr[-300:]}")
    out = r.stdout
    # 真有 17 个策略
    # 简单数: 非空非分隔符行
    n = sum(1 for line in out.splitlines() if line.strip() and "─" not in line and line.split())
    assert n >= 17, f"应 ≥ 17 策略, 实际 {n}: {out[:500]}"


def test_fresh_venv_imports_all_key_modules(fresh_venv_with_wheel):
    """新 venv 真能 import 关键模块 (验 wheel 含所有 .py)"""
    venv_dir = fresh_venv_with_wheel["venv"]
    # 重点验顶层 + cli + backtest (业务核心 + 跑得通的)
    modules_to_test = [
        "forgemind",
        "forgemind.core.backtest.engine",
        "forgemind.core.factors.alpha158",
        "forgemind.cli",
    ]
    failed = []
    for m in modules_to_test:
        r = subprocess.run(
            [str(venv_dir / "bin" / "python"), "-c", f"import {m}; print('OK')"],
            capture_output=True, text=True, timeout=10,
        )
        if r.returncode != 0:
            failed.append((m, r.stderr[-200:]))
    assert not failed, f"以下模块 import 失败: {failed}"
