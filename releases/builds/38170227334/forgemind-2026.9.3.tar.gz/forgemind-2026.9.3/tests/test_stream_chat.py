# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


class TestStreamChat:
    """stream_chat 5 个 provider 都应能跑(真发或降级)"""

    @pytest.mark.asyncio
    async def test_openai_stream_raises_when_not_installed(self):
        """openai 未装时必须抛错,不能 yield 占位字符串

        此前 yield 的是 "[OpenAI not installed]" —— 调用方把它当模型增量
        输出拼进结果,拿到一份看起来正常、实则毫无内容的文本。
        """
        from forgemind.core.ai.providers import (
            ChatMessage,
            OpenAIProvider,
            ProviderConfig,
            ProviderType,
            ProviderUnavailableError,
        )
        # ProviderUnavailableError 必须在 patch __import__ **之前**导入:
        # patch 期间任何 import 都会抛 ImportError
        with patch.dict("sys.modules", {"openai": None}):
            with patch("builtins.__import__", side_effect=ImportError("openai not installed")):
                p = OpenAIProvider(ProviderConfig(
                    provider_type=ProviderType.OPENAI,
                    api_key="fake",
                    model_name="gpt-4o-mini",
                ))
                with pytest.raises(ProviderUnavailableError):
                    async for _ in p.stream_chat(
                            [ChatMessage(role="user", content="hi")]):
                        pass

    @pytest.mark.asyncio
    async def test_anthropic_stream_raises_when_not_installed(self):
        """anthropic 未装时必须抛错,不能 yield 占位字符串"""
        from forgemind.core.ai.providers import (
            AnthropicProvider,
            ChatMessage,
            ProviderConfig,
            ProviderType,
        )
        with patch.dict("sys.modules", {"anthropic": None}):
            p = AnthropicProvider(ProviderConfig(
                provider_type=ProviderType.ANTHROPIC,
                api_key="fake",
                model_name="claude-3-5-sonnet-latest",
            ))
            from forgemind.core.ai.providers import ProviderUnavailableError
            with pytest.raises(ProviderUnavailableError):
                async for _ in p.stream_chat(
                        [ChatMessage(role="user", content="hi")]):
                    pass

    @pytest.mark.asyncio
    async def test_qwen_stream(self):
        """Qwen stream — GenericOpenAICompatProvider"""
        from forgemind.core.ai.providers import (
            ChatMessage,
            GenericOpenAICompatProvider,
            ProviderConfig,
            ProviderType,
        )
        p = GenericOpenAICompatProvider(ProviderConfig(
            provider_type=ProviderType.QWEN,
            api_key="fake",
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
            model_name="qwen-plus",
        ))
        # 不真发请求(没 API key),只验证接口存在且能调用
        assert hasattr(p, "stream_chat")
        # stream_chat 在 API key 失效时降级
        chunks = []
        try:
            async for c in p.stream_chat([ChatMessage(role="user", content="hi")]):
                chunks.append(c)
                if len(chunks) > 100:  # 防止死循环
                    break
        except Exception:
            pass  # 任何异常都接受(网络/限流)

    @pytest.mark.asyncio
    async def test_ollama_stream(self):
        """Ollama 本地 stream — 用 mock 模拟"""
        from forgemind.core.ai.providers import (
            ChatMessage,
            OllamaProvider,
            ProviderConfig,
            ProviderType,
        )
        p = OllamaProvider(ProviderConfig(
            provider_type=ProviderType.OLLAMA,
            base_url="http://localhost:11434",
            model_name="qwen2.5:7b",
        ))
        # 模拟 Ollama /api/chat 流式响应
        with patch("httpx.AsyncClient.stream") as mock_stream:
            mock_response = AsyncMock()
            mock_response.__aiter__ = MagicMock(return_value=iter([
                '{"message": {"content": "Hello"}}',
                '{"message": {"content": " World"}}',
                '{"done": true}',
            ]))
            mock_response.raise_for_status = MagicMock()
            mock_stream.return_value.__aenter__ = AsyncMock(return_value=mock_response)
            mock_stream.return_value.__aexit__ = AsyncMock(return_value=None)

            chunks = []
            try:
                async for c in p.stream_chat([ChatMessage(role="user", content="hi")]):
                    chunks.append(c)
            except Exception:
                pass  # httpx mock 可能不完全

    @pytest.mark.asyncio
    async def test_abstract_stream_chat_in_base(self):
        """BaseProvider.stream_chat 是 abstractmethod"""

        from forgemind.core.ai.providers import BaseProvider
        # 验证 stream_chat 是 abstract
        assert hasattr(BaseProvider, "stream_chat")
        # 验证 abstract 装饰
        method = BaseProvider.stream_chat
        assert getattr(method, "__isabstractmethod__", False) is True

    def test_all_providers_implement_stream_chat(self):
        """5 个 Provider 都应实现 stream_chat"""
        from forgemind.core.ai.providers import (
            AnthropicProvider,
            BaseProvider,
            GenericOpenAICompatProvider,
            OllamaProvider,
            OpenAIProvider,
        )
        for cls in [OpenAIProvider, AnthropicProvider, OllamaProvider, GenericOpenAICompatProvider]:
            assert "stream_chat" in cls.__dict__, f"{cls.__name__} 缺 stream_chat"
            # 验证 override 了 BaseProvider 的 abstractmethod
            assert cls.stream_chat is not BaseProvider.stream_chat


class TestStreamChatIntegration:
    """stream_chat 端到端 — 配合 AsyncIterator 消费"""

    @pytest.mark.integration
    @pytest.mark.asyncio
    async def test_stream_chat_returns_async_iter(self):
        """stream_chat 应返回 AsyncIterator"""
        import inspect

        from forgemind.core.ai.providers import (
            ChatMessage,
            OpenAIProvider,
            ProviderConfig,
            ProviderType,
        )
        p = OpenAIProvider(ProviderConfig(
            provider_type=ProviderType.OPENAI,
            api_key="fake",
            model_name="gpt-4o-mini",
        ))
        gen = p.stream_chat([ChatMessage(role="user", content="hi")])
        # 验证是 async generator
        assert inspect.isasyncgen(gen)
        # 消费掉(避免 ResourceWarning);SDK 缺失时抛错属预期
        from forgemind.core.ai.providers import ProviderUnavailableError
        try:
            async for _ in gen:
                pass
        except ProviderUnavailableError:
            pass
