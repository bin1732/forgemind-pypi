# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

import threading as _threading
from pathlib import Path

import duckdb

from forgemind.core.config.settings import get_settings
from forgemind.core.observability.logging import get_logger

logger = get_logger("forgemind.storage")


def bare_symbol(symbol: str) -> str:
    """把 '600519.SH' / 'sh600519' / 'SH600519' 统一成 DuckDB 里存的 '600519'

    ETL 落库用的是 6 位代码,而 CLI / API / MCP 的入参常常带交易所后缀
    (README 与 `forgemind agent --symbol` 的默认值就是 '600519.SH')。
    不归一化的后果:用户照文档先跑 etl 再跑 agent,后者查不到任何 K 线,
    然后如实报"本地没有行情数据" —— 看起来像数据没拉,其实是格式不匹配。

    归一化必须放在**查询前**,而不是要求每个调用方自己记得剥后缀。
    """
    s = str(symbol).strip().upper()
    for sep in (".", "-", "_"):
        if sep in s:
            s = s.split(sep)[0]
    for pre in ("SH", "SZ", "BJ"):
        if s.startswith(pre) and s[2:].isdigit():
            s = s[2:]
    return s.strip()


def data_freshness(last_date: str | None, today=None) -> str:
    """把"数据最新日期"变成一句人能直接判断的话

    量化工具最容易被忽视的误导:计算完全正确,但依据的是几周前的
    收盘价。用户看到"均线空头排列"却不知道那是上个月的形态。
    这里只做陈述,不做判断 —— 多久算过期取决于策略,不替用户决定。
    """
    import datetime as _dt

    if not last_date:
        return "未知(没有数据)"
    try:
        d = _dt.date.fromisoformat(str(last_date)[:10])
    except ValueError:
        return f"未知(无法解析日期 {last_date!r})"
    today = today or _dt.date.today()
    days = (today - d).days
    if days < 0:
        return f"{d}(未来日期,请检查数据源)"
    if days == 0:
        return f"{d}(今天)"
    if days == 1:
        return f"{d}(昨天)"
    if days <= 7:
        return f"{d}({days} 天前)"
    if days <= 60:
        return f"{d}(**{days} 天前,已明显滞后**)"
    return f"{d}(**{days} 天前,严重过期,请重跑 forgemind etl**)"


class DuckDBStorage:
    """
    DuckDB 单节点 OLAP — 给 Agent / Notebook 用

    用法:
        with DuckDBStorage() as db:
            df = db.query_df("SELECT * FROM market_data WHERE symbol = '600519.SH'")
    """

    def __init__(self, path: str | None = None):
        settings = get_settings()
        self.path = path or settings.duckdb_path
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn: duckdb.DuckDBPyConnection | None = None
        logger.info("duckdb_storage_init", path=self.path)

    def __enter__(self):
        self.conn = duckdb.connect(self.path)
        return self

    def __exit__(self, exc_type, exc_val, _exc_tb):
        if self.conn:
            if exc_type is not None:
                logger.warning(
                    "duckdb_context_exit_with_error",
                    exc_type=exc_type.__name__,
                    exc_msg=str(exc_val) if exc_val else None,
                )
            self.conn.close()
            self.conn = None

    def execute(self, sql: str, params: list | None = None):
        """执行 SQL(insert/update/ddl)"""
        if not self.conn:
            raise RuntimeError("Use within 'with' block")
        if params:
            self.conn.execute(sql, params)
        else:
            self.conn.execute(sql)

    def query_df(self, sql: str, params: list | None = None):
        """查询 → DataFrame"""
        if not self.conn:
            raise RuntimeError("Use within 'with' block")
        if params:
            return self.conn.execute(sql, params).df()
        return self.conn.execute(sql).df()

    def query_scalar(self, sql: str, params: list | None = None):
        """查询 → 单值"""
        df = self.query_df(sql, params)
        if df.empty:
            return None
        return df.iloc[0, 0]


_init_lock = _threading.Lock()
_init_done_for: set[str] = set()


def init_duckdb():
    """初始化 DuckDB — 创建本地表

    进程内单次:同 (db path) 只跑一次 DDL,避免并发线程同时
    CREATE INDEX 触发 DuckDB catalog write-write conflict
    ("TransactionException: Catalog write-write conflict on create
    with ... idx_kline_symbol_date")。新 db path 重新初始化。
    """
    settings = get_settings()
    with _init_lock:
        if settings.duckdb_path in _init_done_for:
            return
        with DuckDBStorage() as db:
            # 注意:曾经有 market_data / factor_cache / decision_cache 三张表
            # 的 CREATE,但全代码库零读零写。删掉,DROP IF EXISTS 兼容老 db。
            # 真要的因子缓存 / 行情缓存等真接代码时再加,别在 schema 里承诺
            # "会写但实际不写"的能力。
            for dead in ("market_data", "factor_cache", "decision_cache"):
                try:
                    db.execute(f"DROP TABLE IF EXISTS {dead}")
                except Exception:  # noqa: BLE001
                    # 老 db 上 DROP 偶发 catalog 错,不影响主流程
                    pass

            # K 线 / 股票列表
            db.execute("""
                CREATE TABLE IF NOT EXISTS stock_list (
                    symbol VARCHAR PRIMARY KEY,
                    name VARCHAR
                )
            """)
            db.execute("""
                CREATE TABLE IF NOT EXISTS kline_daily (
                    date DATE,
                    symbol VARCHAR,
                    open DOUBLE,
                    high DOUBLE,
                    low DOUBLE,
                    close DOUBLE,
                    volume BIGINT,
                    provider VARCHAR,
                    PRIMARY KEY (date, symbol)
                )
            """)
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_kline_symbol_date "
                "ON kline_daily(symbol, date)"
            )

            # 组合快照
            db.execute("""
                CREATE TABLE IF NOT EXISTS portfolio_snapshot (
                    snapshot_id VARCHAR,
                    taken_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    cash DOUBLE NOT NULL,
                    currency VARCHAR DEFAULT 'CNY',
                    total_equity DOUBLE,
                    PRIMARY KEY (snapshot_id)
                )
            """)
            db.execute("""
                CREATE TABLE IF NOT EXISTS portfolio_position (
                    snapshot_id VARCHAR,
                    symbol VARCHAR NOT NULL,
                    quantity DOUBLE NOT NULL,
                    avg_price DOUBLE NOT NULL,
                    unrealized_pnl DOUBLE DEFAULT 0,
                    PRIMARY KEY (snapshot_id, symbol)
                )
            """)

            # === portfolio_decision ===
            # 每个 snapshot 落一组 6 Agent 决策明细,给桌面 UI 多 Agent 面板用
            # (不再让前端硬编码 vote / score / reasoning)
            db.execute("""
                CREATE TABLE IF NOT EXISTS portfolio_decision (
                    snapshot_id VARCHAR,
                    agent VARCHAR NOT NULL,
                    vote VARCHAR,
                    score DOUBLE,
                    confidence DOUBLE,
                    thesis TEXT,
                    evidence TEXT,
                    PRIMARY KEY (snapshot_id, agent)
                )
            """)

            # === signal_history ===
            # MCP output_signal 落盘 + 桌面 signal-table 读真信号
            # 之前 output_signal 只 echo,signal-table 显示 store.signals = [] 永远是空
            db.execute("""
                CREATE TABLE IF NOT EXISTS signal_history (
                    signal_id VARCHAR PRIMARY KEY,
                    emitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    symbol VARCHAR NOT NULL,
                    side VARCHAR NOT NULL,
                    confidence DOUBLE,
                    rationale TEXT,
                    source VARCHAR
                )
            """)
            db.execute(
                "CREATE INDEX IF NOT EXISTS idx_signal_history_emitted_at "
                "ON signal_history(emitted_at)"
            )

            # === backtest_run ===
            # 每次 forgemind backtest 落一行真实指标,给桌面 UI 风险指标面板用
            db.execute("""
                CREATE TABLE IF NOT EXISTS backtest_run (
                    run_id VARCHAR PRIMARY KEY,
                    ran_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    symbol VARCHAR,
                    strategy VARCHAR,
                    total_return DOUBLE,
                    sharpe DOUBLE,
                    sortino DOUBLE,
                    max_drawdown DOUBLE,
                    win_rate DOUBLE,
                    n_trades INTEGER
                )
            """)

            logger.info("duckdb_init_complete", path=settings.duckdb_path)
        _init_done_for.add(settings.duckdb_path)


def save_portfolio_snapshot(portfolio) -> str:
    """把一次组合状态落盘,返回 snapshot_id

    Args:
        portfolio: PortfolioContext(或任何有 cash/positions/total_equity/currency 的对象)

    供 `forgemind agent` 在每次决策后调用,让 MCP 的 query_portfolio 读到真实数据。
    """
    import uuid

    init_duckdb()
    snap_id = f"snap_{uuid.uuid4().hex[:12]}"
    with DuckDBStorage() as db:
        db.execute(
            "INSERT INTO portfolio_snapshot (snapshot_id, cash, currency, total_equity) "
            "VALUES (?, ?, ?, ?)",
            [snap_id, float(portfolio.cash), getattr(portfolio, "currency", "CNY"),
             float(getattr(portfolio, "total_equity", 0.0))],
        )
        for p in portfolio.positions:
            db.execute(
                "INSERT INTO portfolio_position "
                "(snapshot_id, symbol, quantity, avg_price, unrealized_pnl) VALUES (?, ?, ?, ?, ?)",
                [snap_id, p.symbol, float(p.quantity), float(p.avg_price),
                 float(getattr(p, "unrealized_pnl", 0.0))],
            )
    logger.info("portfolio_snapshot_saved", snapshot_id=snap_id,
                n_positions=len(portfolio.positions))
    return snap_id


def save_portfolio_decisions(snapshot_id: str, decisions: list[dict]) -> int:
    """把一组 6 Agent 决策明细落盘,关联到指定 snapshot

    decisions 元素 shape:
        {"agent": "Fundamentals"|"Technical"|"News"|"Bull"|"Bear"|"PM",
         "vote": "buy"|"sell"|"hold",
         "score": float (0-5),
         "confidence": float (0-1),
         "thesis": str,
         "evidence": str (可选,默认空)}

    返回写入行数,缺字段的那条会被跳过但日志告警,不阻断其它 agent 入库。
    之前桌面 UI 的 6 Agent 面板是 6 条 AGENT_VOTES 硬编码(PE 28 / RSI 67
    等全是字符串常量);这条 fix 接真后端数据。
    """
    init_duckdb()
    written = 0
    skipped: list[str] = []
    with DuckDBStorage() as db:
        for d in decisions or []:
            agent = (d.get("agent") or "").strip()
            if not agent:
                skipped.append("<no agent>")
                continue
            try:
                db.execute(
                    "INSERT INTO portfolio_decision "
                    "(snapshot_id, agent, vote, score, confidence, thesis, evidence) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    [
                        snapshot_id,
                        agent,
                        d.get("vote"),
                        float(d.get("score", 0.0)) if d.get("score") is not None else None,
                        float(d.get("confidence", 0.0)) if d.get("confidence") is not None else None,
                        d.get("thesis"),
                        d.get("evidence"),
                    ],
                )
                written += 1
            except Exception as exc:  # noqa: BLE001
                # 单条 agent 失败不阻断(可能 schema 没及时同步)
                skipped.append(f"{agent}({type(exc).__name__})")
    if skipped:
        logger.warning("portfolio_decision_partial_save",
                       snapshot_id=snapshot_id,
                       written=written,
                       skipped=skipped)
    return written


def load_latest_decisions(limit_snapshots: int = 1) -> list[dict]:
    """读最近一组 portfolio_decision(snapshot 维度),给桌面 6 Agent 面板用

    返回:
        [{"agent": "Fundamentals", "vote": "buy", "score": 4,
          "confidence": 0.85, "thesis": "...", "evidence": "..."}]
    没有时返回空列表(让 UI 显示空态而不是假数据)。
    """
    init_duckdb()
    with DuckDBStorage() as db:
        exists = db.query_scalar(
            "SELECT COUNT(*) FROM information_schema.tables "
            "WHERE table_name='portfolio_decision'"
        )
        if not exists:
            return []
        snap_ids = db.query_df(
            "SELECT DISTINCT snapshot_id FROM portfolio_decision "
            "ORDER BY snapshot_id DESC LIMIT ?",
            [int(max(1, limit_snapshots))],
        )
        if snap_ids.empty:
            return []
        # 拿最近一个 snapshot 的所有 agent
        latest_snap = snap_ids.iloc[0]["snapshot_id"]
        rows = db.query_df(
            "SELECT agent, vote, score, confidence, thesis, evidence "
            "FROM portfolio_decision WHERE snapshot_id = ? ORDER BY agent",
            [latest_snap],
        )
    return [
        {
            "agent": r["agent"],
            "vote": r["vote"],
            "score": float(r["score"]) if r["score"] is not None else None,
            "confidence": float(r["confidence"]) if r["confidence"] is not None else None,
            "thesis": r["thesis"],
            "evidence": r["evidence"],
        }
        for _, r in rows.iterrows()
    ]


def save_backtest_run(
    symbol: str, strategy: str, metrics: dict,
) -> str:
    """把一次 backtest 的真实指标落盘,给桌面风险指标面板用

    metrics 期望键(total_return / sharpe / sortino / max_drawdown / win_rate /
    n_trades),缺字段置 None,不抛错 —— 之前桌面 Sharpe 1.42 / Sortino 1.87 /
    Max DD -8.3% / 胜率 58.5% 是写死的,这条 fix 把真回测落下来后桌面就有真数。
    """
    import uuid

    init_duckdb()
    run_id = f"bt_{uuid.uuid4().hex[:12]}"
    with DuckDBStorage() as db:
        db.execute(
            "INSERT INTO backtest_run "
            "(run_id, symbol, strategy, total_return, sharpe, sortino, "
            " max_drawdown, win_rate, n_trades) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                run_id,
                symbol,
                strategy,
                metrics.get("total_return"),
                metrics.get("sharpe"),
                metrics.get("sortino"),
                metrics.get("max_drawdown"),
                metrics.get("win_rate"),
                int(metrics["n_trades"]) if metrics.get("n_trades") is not None else None,
            ],
        )
    logger.info("backtest_run_saved",
                run_id=run_id, symbol=symbol, strategy=strategy,
                sharpe=metrics.get("sharpe"))
    return run_id


def save_signal(
    signal_id: str,
    symbol: str,
    side: str,
    confidence: float,
    rationale: str,
    source: str = "mcp_output_signal",
) -> str:
    """把 output_signal 工具的信号落盘

    之前 output_signal 只 echo,signal-table 显示永远是空 —— 用户在
    terminal 跑了 forgemind signal 之后,桌面 signal-table 不显示。
    落 signal_history 表,桌面从 forgemind://signals resource 拉真信号。

    返回 signal_id(已传,直接回传),错误时抛 RuntimeError 让 MCP 端处理。
    """
    import uuid
    if not signal_id:
        signal_id = f"sig_{uuid.uuid4().hex[:12]}_{symbol}"
    init_duckdb()
    with DuckDBStorage() as db:
        db.execute(
            "INSERT INTO signal_history "
            "(signal_id, symbol, side, confidence, rationale, source) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            [signal_id, symbol, side, float(confidence), rationale, source],
        )
    logger.info("signal_saved", signal_id=signal_id, symbol=symbol, side=side)
    return signal_id


def load_recent_signals(limit: int = 100) -> list[dict]:
    """读最近 N 条真信号,给桌面 signal-table 用

    之前 signal-table 显示 store.signals (来自 useAppStore 默认值 []) ——
    永远是空。现在拉 DuckDB signal_history,按 emitted_at 倒序。
    """
    init_duckdb()
    with DuckDBStorage() as db:
        exists = db.query_scalar(
            "SELECT COUNT(*) FROM information_schema.tables "
            "WHERE table_name='signal_history'"
        )
        if not exists:
            return []
        df = db.query_df(
            "SELECT signal_id, emitted_at, symbol, side, confidence, "
            "rationale, source FROM signal_history "
            "ORDER BY emitted_at DESC LIMIT ?",
            [int(max(1, limit))],
        )
    return [
        {
            "signal_id": r["signal_id"],
            "emitted_at": str(r["emitted_at"]),
            "symbol": r["symbol"],
            "side": r["side"],
            "confidence": float(r["confidence"]) if r["confidence"] is not None else None,
            "rationale": r["rationale"],
            "source": r["source"],
        }
        for _, r in df.iterrows()
    ]


def load_latest_backtest_run(symbol: str | None = None) -> dict | None:
    """读最近一次 backtest_run 指标

    symbol 不传时返回任意最近一次(适合桌面"风险指标"展示整体);
    传 symbol 时返回该 symbol 最近一次(适合按标的展示)。

    返回 None 时桌面 UI 应显示 "—",绝不编造。
    """
    init_duckdb()
    with DuckDBStorage() as db:
        exists = db.query_scalar(
            "SELECT COUNT(*) FROM information_schema.tables "
            "WHERE table_name='backtest_run'"
        )
        if not exists:
            return None
        if symbol:
            df = db.query_df(
                "SELECT run_id, ran_at, symbol, strategy, total_return, sharpe, "
                "sortino, max_drawdown, win_rate, n_trades FROM backtest_run "
                "WHERE symbol = ? ORDER BY ran_at DESC LIMIT 1",
                [symbol],
            )
        else:
            df = db.query_df(
                "SELECT run_id, ran_at, symbol, strategy, total_return, sharpe, "
                "sortino, max_drawdown, win_rate, n_trades FROM backtest_run "
                "ORDER BY ran_at DESC LIMIT 1"
            )
    if df.empty:
        return None
    r = df.iloc[0]
    return {
        "run_id": r["run_id"],
        "ran_at": str(r["ran_at"]),
        "symbol": r["symbol"],
        "strategy": r["strategy"],
        "total_return": float(r["total_return"]) if r["total_return"] is not None else None,
        "sharpe": float(r["sharpe"]) if r["sharpe"] is not None else None,
        "sortino": float(r["sortino"]) if r["sortino"] is not None else None,
        "max_drawdown": float(r["max_drawdown"]) if r["max_drawdown"] is not None else None,
        "win_rate": float(r["win_rate"]) if r["win_rate"] is not None else None,
        "n_trades": int(r["n_trades"]) if r["n_trades"] is not None else None,
    }


def load_latest_portfolio() -> dict | None:
    """读回最新一次组合快照;没有任何快照时返回 None(绝不编造)"""
    init_duckdb()
    with DuckDBStorage() as db:
        exists = db.query_scalar(
            "SELECT COUNT(*) FROM information_schema.tables "
            "WHERE table_name='portfolio_snapshot'"
        )
        if not exists:
            return None
        latest = db.query_df(
            "SELECT snapshot_id, cash, currency, total_equity FROM portfolio_snapshot "
            "ORDER BY taken_at DESC LIMIT 1"
        )
        if latest.empty:
            return None
        row = latest.iloc[0]
        pos = db.query_df(
            "SELECT symbol, quantity, avg_price, unrealized_pnl FROM portfolio_position "
            "WHERE snapshot_id = ? ORDER BY symbol",
            [row["snapshot_id"]],
        )
    positions = [
        {
            "symbol": r["symbol"],
            "quantity": float(r["quantity"]),
            "avg_price": float(r["avg_price"]),
            "unrealized_pnl": float(r["unrealized_pnl"]),
        }
        for _, r in pos.iterrows()
    ]
    return {
        "snapshot_id": row["snapshot_id"],
        "cash": float(row["cash"]),
        "currency": row["currency"],
        "total_equity": float(row["total_equity"]),
        "positions": positions,
    }


if __name__ == "__main__":
    init_duckdb()
