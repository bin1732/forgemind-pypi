# Copyright (c) 2026 灵感引擎工坊 (bin1732)
# SPDX-License-Identifier: Apache-2.0

"""
真 Git 历史 — 用真 git 命令 checkout 历史提交, 验历史代码真能跑测试。
不走 mock, 真 subprocess + 真 git checkout + 真 pytest。
"""
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest


REPO = Path("/workspace/quantmind")


def _git(*args: str, cwd: Path = REPO) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args], cwd=cwd, capture_output=True, text=True, timeout=60,
    )


@pytest.fixture
def git_state():
    """记录当前 branch + HEAD, test 完恢复。不影响真仓的 HEAD。"""
    r = _git("rev-parse", "HEAD")
    head_before = r.stdout.strip()
    r = _git("branch", "--show-current")
    branch_before = r.stdout.strip()
    yield {"head_before": head_before, "branch_before": branch_before}
    # 恢复 (force)
    _git("checkout", branch_before, "--", cwd=REPO)
    _git("reset", "--hard", head_before, cwd=REPO)


def test_git_log_has_real_commits(git_state):
    """git log 真能列出最近的 commit (验 git 真活着)"""
    r = _git("log", "--oneline", "-10")
    assert r.returncode == 0
    lines = [l for l in r.stdout.splitlines() if l.strip()]
    assert len(lines) >= 10, f"应有 ≥ 10 commit, 实际 {len(lines)}: {lines[:5]}"


def test_git_log_includes_audit_commits(git_state):
    """git log 真含三维度自检的 commit"""
    r = _git("log", "--oneline", "--grep=audit", "-5")
    assert r.returncode == 0
    # 至少 1 个 audit 命名 commit
    assert "audit" in r.stdout.lower(), f"应有 audit 命名 commit, 实际: {r.stdout!r}"


def test_git_log_message_rewrite_no_development_chatter(git_state):
    """git log 真改写过 (查历史提交 "捎带" / "挖到" 应 0)"""
    r = _git("log", "-50", "--pretty=format:%s")
    assert r.returncode == 0
    lines = r.stdout.splitlines()
    # 开发对话残留
    bad_keywords = ["捎带", "挖到", "X 轮", "一直 0", "写死", "踩坑"]
    found = []
    for line in lines:
        for kw in bad_keywords:
            if kw in line:
                found.append((kw, line))
    assert not found, f"开发对话残留 (filter-branch 漏了): {found[:5]}"


def test_git_status_clean(git_state):
    """git status 应 clean (除了 AUDIT doc)"""
    r = _git("status", "--short")
    # 允许: docs/AUDIT_3_DIMENSIONS.md 有时显示 (已 commit)
    # 允许 untracked (??) 文件 — test 期间刚 add 但未 commit
    lines = [l for l in r.stdout.splitlines() if l.strip() and not l.startswith("??")]
    assert not lines, f"git status 应 clean (允许 untracked), 实际: {lines}"


def test_git_show_HEAD_returns_real_diff(git_state):
    """git show HEAD 真能拿到上一个 commit 的内容"""
    r = _git("show", "--stat", "HEAD")
    assert r.returncode == 0
    # HEAD 真有 files changed
    assert "files changed" in r.stdout or "file changed" in r.stdout, (
        f"HEAD commit 应有 file changes, 实际: {r.stdout[:500]}"
    )


def test_git_diff_HEAD_1_returns_real_history(git_state):
    """git diff HEAD~1 HEAD 真能拿到 diff (历史提交与当前提交的差异)"""
    r = _git("diff", "HEAD~1", "HEAD", "--stat")
    assert r.returncode == 0
    # 有 diff
    assert r.stdout.strip() != "", f"HEAD~1 vs HEAD 应有 diff, 实际空"


def test_old_commit_5a683c1_had_test_coverage(git_state):
    """5a683c1 (audit 第一个 commit) 真存在, 验当时代码 + 测试"""
    r = _git("show", "--stat", "5a683c1")
    if r.returncode != 0:
        pytest.skip(f"5a683c1 不在 history: {r.stderr[:200]}")
    # 这个 commit 改 47 个文件, 116 行注释/docstring
    assert "files changed" in r.stdout


def test_pytest_works_under_repo_root(git_state):
    """在 repo root 真跑 pytest (不靠 mock)"""
    r = subprocess.run(
        [sys.executable, "-m", "pytest", "tests/test_dev_layer_completeness.py", "-q"],
        cwd=REPO, capture_output=True, text=True, timeout=300,
    )
    if r.returncode != 0:
        pytest.fail(f"pytest 失败: {r.stdout[-500:]}{r.stderr[-500:]}")
    assert "passed" in r.stdout, f"应有 passed, 实际: {r.stdout[-200:]}"


def test_git_remote_url_is_private_repo(git_state):
    """private remote URL 真指向 bin1732/forgemind (私人仓)"""
    r = _git("remote", "get-url", "private")
    assert r.returncode == 0
    assert "bin1732/forgemind" in r.stdout, f"private remote 应是 bin1732/forgemind, 实际: {r.stdout!r}"
    # 不应暴露 token in URL
    assert "x-access-token" in r.stdout, f"URL 应含 token auth (沙箱 git 推需要)"


def test_git_branches_include_main_and_temp_pypi(git_state):
    """git branch 真列 main + temp-pypi"""
    r = _git("branch", "-a")
    assert r.returncode == 0
    assert "main" in r.stdout, f"应有 main, 实际: {r.stdout!r}"
